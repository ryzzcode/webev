module.exports = {
  tokens: "8243412737:AAHvI-Mv9I1DyV4RBt2nSPYLCfwagu-matM",  // Ubah Jadi Token Bot Mu !!!
  owner: "6217597836", // Ubah Jadi Id Mu !!!
  port: "2000", // Ubah Jadi Port Panel Mu !!!
  ipvps: "152.42.213.5" // Ubah Jadi Ip Vps Mu !!!
};