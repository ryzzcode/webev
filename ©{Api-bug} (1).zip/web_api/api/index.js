const app = require("../index");

// handler untuk Vercel
module.exports = (req, res) => app(req, res);